# data/

These are STARTER (empty) copies of the three JSON files the original
2M/Chada script maintained. On a real installation the plugin writes its
live copies to `/etc/epgimport/jedi_epg/` (see `translators/darija.py`):

- `translation_cache.json` — cache of French→Darija translations already
  produced by the Google-Translate-free fallback, so the same title is
  never re-translated over the network twice.
- `custom_dictionary.json` — operator-editable overrides. Anything you add
  here takes priority over the built-in `official_titles` dictionary in
  `translators/darija.py`. Format: `{"normalized french text": "الترجمة"}`.
- `unknown_shows.json` — titles the translator could not confidently
  translate (Google returned the same text back unchanged). Review these
  periodically and copy good translations into `custom_dictionary.json`.

The copies in this folder are only templates copied into place by
`installer/install.sh` on first install; they are never overwritten on
upgrade so your accumulated cache/dictionary survives plugin updates.
