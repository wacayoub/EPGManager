# -*- coding: utf-8 -*-
"""
sources/almajd.py

Ported from 5.ALMAJD.py. All 11 channels, Arabic AM/PM time parsing, real
end-time computation, deduplication, and icon URLs preserved.

BUG FIX: the original script always called save_to_xmltv(epg) even when
`epg` was an empty list, which would silently overwrite a good almajdtv.xml
with an empty <tv> document. The shared XMLTVBuilder.save() now refuses to
write when min_programs isn't met, so a failed scrape leaves the previous
good file untouched.
"""

from datetime import datetime, timedelta
import time

from .base import EPGSource
from ..core.parser import get_soup, SourceWarning
from ..core.xmltv import Programme

BASE_FETCH_URL = "https://almajdtv.com/tvguide/Channels/fetch-programs.php"
REQUEST_DELAY_SEC = 0.5

CHANNELS = {
    "almajd": 1,
    "almajd-holy-quran": 2,
    "almajd-holy-hadeeth": 3,
    "almajd-islamic-science": 4,
    "almajd-documentary": 6,
    "almajd-nature": 7,
    "majd": 9,
    "basma": 10,
    "rawda": 11,
    "masah": 12,
    "al-ajaweed": 13,
}

_ARABIC_DIGITS = {"٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4",
                   "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9"}


def arabic_to_24(time_str):
    original = time_str
    time_str = time_str.replace("ص", "AM").replace("م", "PM").strip()
    for ar, en in _ARABIC_DIGITS.items():
        time_str = time_str.replace(ar, en)
    try:
        return datetime.strptime(time_str, "%I:%M %p")
    except ValueError:
        return None


class AlmajdSource(EPGSource):
    id = "almajd"
    name = "Almajd"
    output_filename = "almajdtv.xml"
    default_days = 2   # matches original DAYS_FORWARD; site rarely publishes further out
    max_days = 3        # hard cap: almajdtv.com's fetch-programs.php has never been
                          # observed returning more than a couple of days forward -
                          # requesting more just wastes requests/time, not a real fix
    min_programs = 5

    def fetch(self, downloader, tzm, days, config, builder):
        today = tzm.now()
        raw_epg = []

        for ch_name, ch_id in CHANNELS.items():
            icon = ("https://almajdtv.com/tvguide/assets/images/channels/logo/%s.webp"
                     % ch_name.replace("-", ""))
            builder.add_channel(ch_name, [(ch_name.replace("-", " ").title(), None)], icon=icon)

            for i in range(days):
                day = today + timedelta(days=i)
                progs = self._fetch_day(downloader, ch_id, ch_name, icon, day)
                raw_epg.extend(progs)
                time.sleep(REQUEST_DELAY_SEC)

        if not raw_epg:
            raise SourceWarning("Almajd: no programmes found across any channel")

        return self._build_programmes(raw_epg, tzm)

    def _fetch_day(self, downloader, channel_id, channel_name, icon, date):
        payload = {
            "program_date": date.strftime("%Y-%m-%d"),
            "channel_id_related": str(channel_id),
        }
        resp = downloader.get_or_none(
            BASE_FETCH_URL, data=payload, method="POST",
            extra_headers={"Referer": "https://almajdtv.com/tvguide/"})
        if resp is None:
            return []

        resp.encoding = "utf-8"
        soup = get_soup(resp.text)
        if soup is None:
            return []

        programs = []
        for row in soup.select("tr.tr_program"):
            title_el = row.select_one(".td_title a")
            time_el = row.select_one(".td_time span")
            desc_el = row.select_one(".td_desc")
            description = desc_el.get_text(separator=" ", strip=True) if desc_el else ""

            if title_el and time_el:
                programs.append({
                    "channel_id": channel_name,
                    "title": title_el.get_text(strip=True),
                    "description": description,
                    "start_time": time_el.get_text(strip=True),
                    "date": date,
                })
        return programs

    def _build_programmes(self, epg_list, tzm):
        enriched = []
        for e in epg_list:
            t = arabic_to_24(e["start_time"])
            if not t:
                continue
            start_local = tzm.localize(datetime.combine(e["date"].date(), t.time()))
            enriched.append(dict(e, _start_local=start_local))

        seen = set()
        deduped = []
        for e in enriched:
            key = (e["channel_id"], e["_start_local"], e["title"])
            if key not in seen:
                seen.add(key)
                deduped.append(e)

        by_channel = {}
        for e in deduped:
            by_channel.setdefault(e["channel_id"], []).append(e)

        programmes = []
        for ch_id, progs in by_channel.items():
            progs.sort(key=lambda p: p["_start_local"])
            for idx, prog in enumerate(progs):
                start_local = prog["_start_local"]
                stop_local = None
                if idx + 1 < len(progs):
                    candidate = progs[idx + 1]["_start_local"]
                    if candidate > start_local:
                        stop_local = candidate
                programmes.append(Programme(
                    channel_id=ch_id,
                    start=start_local,
                    stop=stop_local,  # None -> XMLTVBuilder computes the default duration
                    title=prog["title"],
                    desc=prog["description"] or prog["title"],
                    lang="ar",
                ))
        return programmes
