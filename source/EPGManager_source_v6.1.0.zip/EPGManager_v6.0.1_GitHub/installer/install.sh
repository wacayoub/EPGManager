#!/bin/sh
# ==========================================================================
# install.sh - EPG Manager installer for Vu+/Enigma2
#
# This is a LOCAL installer (spec section 41: "if there is no repository
# yet, provide a local installer"). It does not invent a feed/opkg
# repository URL. Run this script FROM THE DIRECTORY THAT CONTAINS THIS
# install.sh file (i.e. the EPGManager project root), on the receiver
# itself (via telnet/ssh) or through an image's file manager + "execute".
#
# What it does, in order (spec section 41 items 1-10):
#   1. Detect architecture
#   2. Detect Enigma2 image
#   3. Detect Python version
#   4. Create target directories
#   5. Install plugin files
#   6. Check dependencies (via core/dependencies.py)
#   7. Attempt to install MISSING HARD dependencies via the image's own
#      package manager (opkg) ONLY - never pip, never compiles anything
#   8. Create default configuration
#   9. Register the plugin (Enigma2 auto-discovers Plugins/Extensions/*,
#      nothing extra to "register" - but we verify the target path is on
#      the plugin scan path and warn if not)
#  10. Enable automatic scheduling (nothing to do here beyond installing
#      plugin.py itself - the scheduler is armed at Enigma2 session start,
#      see plugin.py; this script does NOT touch any crontab)
# ==========================================================================

set -e

PLUGIN_NAME="EPGManager"
INSTALL_ROOT="/usr/lib/enigma2/python/Plugins/Extensions"
TARGET_DIR="$INSTALL_ROOT/$PLUGIN_NAME"
EPG_OUTPUT_DIR="/etc/epgimport/jedi_epg"
SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "=========================================================="
echo " EPG Manager installer"
echo "=========================================================="

# -- 1/2/3: environment detection ----------------------------------------
ARCH="$(uname -m 2>/dev/null || echo unknown)"
echo "[*] Detected architecture: $ARCH"

PYTHON_BIN=""
for candidate in python3 python3.9 python3.8 python3.7 python3.11; do
    if command -v "$candidate" >/dev/null 2>&1; then
        PYTHON_BIN="$candidate"
        break
    fi
done

if [ -z "$PYTHON_BIN" ]; then
    echo "[!] ERROR: no python3 interpreter found on this receiver."
    echo "    EPG Manager requires Python 3. Aborting installation."
    exit 1
fi

PYTHON_VERSION="$($PYTHON_BIN -c 'import sys; print("%d.%d.%d" % sys.version_info[:3])')"
echo "[*] Detected Python: $PYTHON_BIN ($PYTHON_VERSION)"

IMAGE_LABEL="unknown"
if [ -f /etc/image-version ]; then
    IMAGE_LABEL="$(cat /etc/image-version 2>/dev/null || echo unknown)"
fi
echo "[*] Detected image-version: $IMAGE_LABEL"

# -- 4: create target directories ----------------------------------------
echo "[*] Creating directories..."
mkdir -p "$TARGET_DIR"
mkdir -p "$EPG_OUTPUT_DIR"

# -- 5: install plugin files ----------------------------------------------
echo "[*] Copying plugin files from $SCRIPT_DIR to $TARGET_DIR ..."
for item in __init__.py plugin.py plugin.png version.py core sources translators ui config; do
    if [ -e "$SCRIPT_DIR/$item" ]; then
        cp -r "$SCRIPT_DIR/$item" "$TARGET_DIR/"
    else
        echo "[!] WARNING: expected item '$item' not found in $SCRIPT_DIR - skipping"
    fi
done


# -- 6/7: dependency check + best-effort opkg install of HARD deps -------
echo "[*] Checking Python dependencies..."
DEP_REPORT="$($PYTHON_BIN "$TARGET_DIR/core/dependencies.py" 2>/dev/null || true)"
echo "$DEP_REPORT"

MISSING_HARD="$($PYTHON_BIN -c "
import sys
sys.path.insert(0, '$TARGET_DIR/..')
try:
    from $PLUGIN_NAME.core import dependencies
except Exception:
    sys.path.insert(0, '$TARGET_DIR')
    import importlib.util
    spec = importlib.util.spec_from_file_location('dependencies', '$TARGET_DIR/core/dependencies.py')
    dependencies = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(dependencies)
report = dependencies.scan()
print(' '.join(report['missing_hard']))
" 2>/dev/null || true)"

if [ -n "$MISSING_HARD" ]; then
    echo "[!] Missing REQUIRED dependencies: $MISSING_HARD"
    if command -v opkg >/dev/null 2>&1; then
        echo "[*] Attempting install via opkg (no pip, no compilation)..."
        opkg update >/dev/null 2>&1 || true
        for mod in $MISSING_HARD; do
            case "$mod" in
                requests) PKG="python3-requests" ;;
                pytz) PKG="python3-pytz" ;;
                *) PKG="" ;;
            esac
            if [ -n "$PKG" ]; then
                echo "    opkg install $PKG"
                opkg install "$PKG" || echo "    [!] opkg install $PKG failed - install it manually"
            fi
        done
    else
        echo "[!] 'opkg' not found - please install the following manually via"
        echo "    your image's package manager: $MISSING_HARD"
    fi
else
    echo "[*] All required dependencies are present."
fi

# -- 8: seed default configuration ----------------------------------------
if [ ! -f /etc/enigma2/epgmanager.conf ]; then
    echo "[*] Seeding default configuration at /etc/enigma2/epgmanager.conf"
    cp "$SCRIPT_DIR/config/defaults.json" /etc/enigma2/epgmanager.conf
else
    echo "[*] Existing /etc/enigma2/epgmanager.conf found - leaving it untouched."
fi

# Seed the three preserved translation/dictionary JSON files ONLY if they
# don't already exist (never clobber an operator's accumulated cache).
for f in translation_cache.json custom_dictionary.json unknown_shows.json; do
    if [ ! -f "$EPG_OUTPUT_DIR/$f" ] && [ -f "$SCRIPT_DIR/data/$f" ]; then
        cp "$SCRIPT_DIR/data/$f" "$EPG_OUTPUT_DIR/$f"
        echo "[*] Seeded $EPG_OUTPUT_DIR/$f"
    fi
done

# -- 9: verify install path is on Enigma2's plugin scan path --------------
if [ ! -d "$INSTALL_ROOT" ]; then
    echo "[!] WARNING: $INSTALL_ROOT does not exist on this system."
    echo "    This does not look like a standard Enigma2 image layout - the"
    echo "    plugin was still copied to $TARGET_DIR, but Enigma2 may not"
    echo "    discover it. Check your image's plugin path."
fi

# -- 10: nothing further needed - explicitly confirm no cron was touched -
echo
echo "=========================================================="
echo " Installation complete."
echo " No crontab entries were created or modified by this installer."
echo " The plugin schedules its own updates internally via eTimer once"
echo " Enigma2 restarts (see plugin.py / core/scheduler.py)."
echo
echo " IMPORTANT: if you are migrating from the old cron-based scripts,"
echo " remove their crontab entries yourself (see the 'root' crontab file"
echo " you were using before) so updates don't run twice."
echo "=========================================================="
echo
echo "Next step: restart Enigma2 (or reboot the receiver) for the plugin"
echo "to appear under Menu -> Extensions / Plugins -> EPG Manager."
