#!/bin/sh
# ==========================================================================
# uninstall.sh - EPG Manager uninstaller for Vu+/Enigma2
#
# Per spec section 42:
#   - removes plugin files
#   - removes scheduler registration (implicit: the scheduler only exists
#     while plugin.py exists; removing the files removes the timer)
#   - PRESERVES EPG XML files by default
#   - PRESERVES user configuration by default
#   - optionally removes cache/logs/config/EPG files if explicitly asked
# ==========================================================================

set -e

PLUGIN_NAME="EPGManager"
TARGET_DIR="/usr/lib/enigma2/python/Plugins/Extensions/$PLUGIN_NAME"
EPG_OUTPUT_DIR="/etc/epgimport/jedi_epg"
CONFIG_FILE="/etc/enigma2/epgmanager.conf"

REMOVE_EPG=0
REMOVE_CONFIG=0
REMOVE_CACHE=0

for arg in "$@"; do
    case "$arg" in
        --remove-epg) REMOVE_EPG=1 ;;
        --remove-config) REMOVE_CONFIG=1 ;;
        --remove-cache) REMOVE_CACHE=1 ;;
        --purge-all) REMOVE_EPG=1; REMOVE_CONFIG=1; REMOVE_CACHE=1 ;;
        --help)
            echo "Usage: $0 [--remove-epg] [--remove-config] [--remove-cache] [--purge-all]"
            echo "  (no args)        Remove plugin code only. EPG files, config, and"
            echo "                   translation caches are left in place (default,"
            echo "                   safest option)."
            echo "  --remove-epg     Also delete the generated *.xml EPG files."
            echo "  --remove-config  Also delete /etc/enigma2/epgmanager.conf."
            echo "  --remove-cache   Also delete translation_cache.json,"
            echo "                   unknown_shows.json (custom_dictionary.json is"
            echo "                   kept unless --purge-all is used, since it is"
            echo "                   operator-authored content)."
            echo "  --purge-all      Remove everything, including custom_dictionary.json."
            exit 0
            ;;
    esac
done

echo "=========================================================="
echo " EPG Manager uninstaller"
echo "=========================================================="

if [ -d "$TARGET_DIR" ]; then
    echo "[*] Removing plugin files from $TARGET_DIR"
    rm -rf "$TARGET_DIR"
else
    echo "[*] $TARGET_DIR not found - already uninstalled?"
fi

if [ "$REMOVE_EPG" = "1" ]; then
    echo "[*] Removing generated EPG XML files from $EPG_OUTPUT_DIR"
    rm -f "$EPG_OUTPUT_DIR"/medi1tv_ar.xml \
          "$EPG_OUTPUT_DIR"/2M_Chada.xml \
          "$EPG_OUTPUT_DIR"/snrt.xml \
          "$EPG_OUTPUT_DIR"/bein.xml \
          "$EPG_OUTPUT_DIR"/almajdtv.xml \
          "$EPG_OUTPUT_DIR"/arryadia_snrt.xml \
          "$EPG_OUTPUT_DIR"/*.xml.bak 2>/dev/null || true
else
    echo "[*] Keeping generated EPG XML files (pass --remove-epg to delete them)"
fi

if [ "$REMOVE_CONFIG" = "1" ]; then
    echo "[*] Removing $CONFIG_FILE"
    rm -f "$CONFIG_FILE"
else
    echo "[*] Keeping $CONFIG_FILE (pass --remove-config to delete it)"
fi

if [ "$REMOVE_CACHE" = "1" ]; then
    echo "[*] Removing translation_cache.json and unknown_shows.json"
    rm -f "$EPG_OUTPUT_DIR/translation_cache.json" "$EPG_OUTPUT_DIR/unknown_shows.json"
    if echo "$*" | grep -q -- "--purge-all"; then
        echo "[*] --purge-all: also removing custom_dictionary.json"
        rm -f "$EPG_OUTPUT_DIR/custom_dictionary.json"
        rm -f "$EPG_OUTPUT_DIR/.hijri_offset_cache.json"
    fi
else
    echo "[*] Keeping translation cache / custom dictionary (pass --remove-cache to delete)"
fi

echo
echo "=========================================================="
echo " Uninstall complete. Restart Enigma2 to fully unload the plugin."
echo "=========================================================="
