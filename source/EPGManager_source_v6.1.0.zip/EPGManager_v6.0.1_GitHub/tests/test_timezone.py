# -*- coding: utf-8 -*-
"""
tests/test_timezone.py

Run with:
    python3 -m unittest EPGManager.tests.test_timezone -v
"""

import unittest
from datetime import datetime

from ..core.timezone_manager import TimezoneManager


class TestTimezoneManager(unittest.TestCase):
    def setUp(self):
        # Disable the network-dependent Hijri cross-check for deterministic,
        # offline unit tests - it's tested separately below.
        self.tzm = TimezoneManager(use_hijri_crosscheck=False)

    def test_localize_returns_aware_datetime(self):
        naive = datetime(2026, 1, 15, 20, 0, 0)
        aware = self.tzm.localize(naive)
        self.assertIsNotNone(aware.tzinfo)

    def test_localize_outside_ramadan_is_utc_plus_1(self):
        # January is never Ramadan-adjacent - should be the standard +1.
        naive = datetime(2026, 1, 15, 12, 0, 0)
        aware = self.tzm.localize(naive)
        offset_hours = aware.utcoffset().total_seconds() / 3600
        self.assertEqual(offset_hours, 1)

    def test_format_xmltv_shape(self):
        naive = datetime(2026, 1, 15, 20, 30, 0)
        aware = self.tzm.localize(naive)
        formatted = self.tzm.format_xmltv(aware)
        # "YYYYMMDDHHMMSS +ZZZZ"
        self.assertRegex(formatted, r"^\d{14} [+-]\d{4}$")

    def test_today_midnight_has_zero_time_components(self):
        midnight = self.tzm.today_midnight()
        self.assertEqual((midnight.hour, midnight.minute, midnight.second), (0, 0, 0))


class TestHijriCrossCheckFallback(unittest.TestCase):
    """When the Hijri API is unreachable, the manager must trust the
    tzdata-derived offset rather than crash or silently mis-time
    everything (this mirrors the original 2M/Chada script's fallback
    philosophy)."""

    def test_crosscheck_failure_does_not_raise(self):
        tzm = TimezoneManager(use_hijri_crosscheck=True, http_timeout=0.001)
        naive = datetime(2026, 3, 15, 12, 0, 0)
        try:
            aware = tzm.localize(naive)
        except Exception as e:
            self.fail("localize() must never raise even if the Hijri API is unreachable: %s" % e)
        self.assertIsNotNone(aware.tzinfo)


if __name__ == "__main__":
    unittest.main()
