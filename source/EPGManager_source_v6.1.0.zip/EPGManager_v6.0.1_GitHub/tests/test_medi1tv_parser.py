# -*- coding: utf-8 -*-
"""
tests/test_medi1tv_parser.py

Tests sources/medi1tv.py's parser against markup shaped like the REAL
live site (fetched and inspected 2026-08-09 via
https://www.medi1tv.com/fr/programme.aspx) - a flat, ordered sequence of
<a> tags per programme: "HH:MM Title", an empty link, a description link,
"Page de l'émission" / "Voir les JTs", then a thumbnail.

Run with:
    python3 -m unittest EPGManager.tests.test_medi1tv_parser -v
"""

import datetime
import unittest

from ..sources.medi1tv import Medi1TVSource

# Shaped directly after the real fetched page structure (see module
# docstring in sources/medi1tv.py) - times, titles, and one representative
# long-form description, interleaved with the boilerplate links that
# appear on the real page between programmes.
SAMPLE_HTML = """
<div class="grille">
  <a href="/fr/emission/232/Depuis-Washington">05:15 Depuis Washington</a>
  <a href="/fr/emission/232/Depuis-Washington"></a>
  <a href="/fr/emission/232/Depuis-Washington">Une emission au coeur de debats strategiques et internationaux.</a>
  <a href="/fr/emission/232/Depuis-Washington"></a>
  <a href="/fr/emission/232/Depuis-Washington">Page de l'émission</a>

  <a href="/fr/jt/09-08-2026">07:00 MEDI1 LA MATINALE</a>
  <a href="/fr/jt/09-08-2026"></a>
  <a href="/fr/jt/09-08-2026">/fr/jt/09-08-2026</a>
  <a href="/fr/jt/09-08-2026"></a>
  <a href="/fr/jt/09-08-2026">Voir les JTs</a>

  <a href="/fr/emission/449/Alternatives">10:15 Alternatives</a>

  <a href="/fr/jt/09-08-2026">13:00 Le Grand Journal de Midi</a>
  <a href="/fr/jt/09-08-2026"></a>
  <a href="/fr/jt/09-08-2026">Tranche d'information: Journal d'actualite, revues de presse, meteo.</a>
  <a href="/fr/jt/09-08-2026"></a>
  <a href="/fr/jt/09-08-2026">Voir les JTs</a>

  <a href="/fr/emission/399/FRONTALES">23:15 FRONTALES</a>
  <a href="/fr/emission/399/FRONTALES"></a>
  <a href="/fr/emission/399/FRONTALES">Un rendez-vous hebdomadaire qui traite les sujets qui interessent les Marocains.</a>
  <a href="/fr/emission/399/FRONTALES">Page de l'émission</a>
</div>
"""


class TestMedi1TVParser(unittest.TestCase):
    def setUp(self):
        self.source = Medi1TVSource()
        self.today = datetime.date(2026, 8, 9)

    def test_finds_all_programmes_in_realistic_markup(self):
        programs = self.source._parse_day(SAMPLE_HTML, self.today)
        self.assertEqual(len(programs), 5)

    def test_extracts_correct_times_and_titles(self):
        programs = self.source._parse_day(SAMPLE_HTML, self.today)
        times_titles = [(p["start"].strftime("%H:%M"), p["title"]) for p in programs]
        self.assertIn(("05:15", "Depuis Washington"), times_titles)
        self.assertIn(("07:00", "MEDI1 LA MATINALE"), times_titles)
        self.assertIn(("10:15", "Alternatives"), times_titles)
        self.assertIn(("13:00", "Le Grand Journal de Midi"), times_titles)
        self.assertIn(("23:15", "FRONTALES"), times_titles)

    def test_extracts_real_descriptions_not_just_placeholder(self):
        programs = self.source._parse_day(SAMPLE_HTML, self.today)
        washington = next(p for p in programs if p["title"] == "Depuis Washington")
        self.assertIn("strategiques", washington["desc"])
        self.assertNotEqual(washington["desc"], "لا توجد تفاصيل")

    def test_short_program_with_no_description_gets_placeholder(self):
        programs = self.source._parse_day(SAMPLE_HTML, self.today)
        alternatives = next(p for p in programs if p["title"] == "Alternatives")
        self.assertEqual(alternatives["desc"], "لا توجد تفاصيل")

    def test_description_lookahead_stops_at_next_programme(self):
        """The lookahead for a description must never leak text belonging
        to the NEXT programme - e.g. 'Alternatives' (which has no
        description of its own) must not accidentally pick up
        '13:00 Le Grand Journal de Midi' text as its description."""
        programs = self.source._parse_day(SAMPLE_HTML, self.today)
        alternatives = next(p for p in programs if p["title"] == "Alternatives")
        self.assertNotIn("Grand Journal", alternatives["desc"])

    def test_empty_html_returns_empty_list(self):
        self.assertEqual(self.source._parse_day("", self.today), [])
        self.assertEqual(self.source._parse_day(None, self.today), [])

    def test_no_matching_links_returns_empty_list(self):
        garbage = "<div><a href='/x'>Menu</a><a href='/y'>Contact</a></div>"
        self.assertEqual(self.source._parse_day(garbage, self.today), [])

    def test_midnight_crossing_bumps_to_next_day(self):
        html = """
        <a href="/x">23:00 Late Show</a>
        <a href="/y">00:30 After Midnight Show</a>
        """
        programs = self.source._parse_day(html, self.today)
        self.assertEqual(len(programs), 2)
        self.assertEqual(programs[0]["start"].date(), self.today)
        self.assertEqual(programs[1]["start"].date(), self.today + datetime.timedelta(days=1))


if __name__ == "__main__":
    unittest.main()
