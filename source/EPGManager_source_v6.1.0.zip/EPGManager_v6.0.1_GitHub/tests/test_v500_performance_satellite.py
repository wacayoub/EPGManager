# -*- coding: utf-8 -*-
import json
import os
import tempfile
import unittest

from ..core import channel_mapper
from ..core.mapping_store import MappingStore


class V500PerformanceSatelliteTests(unittest.TestCase):
    def test_classify_satellite_and_iptv(self):
        self.assertEqual(channel_mapper.classify_service_ref('1:0:1:1234:5678:9ABC:00000000:0:0:0:'), 'SAT')
        self.assertEqual(channel_mapper.classify_service_ref('4097:0:1:0:0:0:0:0:0:0:http%3a//example/test'), 'IPTV')

    def test_parse_dvb_ids(self):
        data = channel_mapper.parse_dvb_ids('1:0:1:1234:5678:9ABC:0ABCDEF0:0:0:0:')
        self.assertEqual(data['sid'], 0x1234)
        self.assertEqual(data['tsid'], 0x5678)
        self.assertEqual(data['onid'], 0x9ABC)
        self.assertEqual(data['namespace'], 0x0ABCDEF0)

    def test_mapping_history_backup_and_undo(self):
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, 'map.json')
            store = MappingStore(path=path)
            store.set('src', 'chan', ['1:0:1:1:2:3:4:0:0:0:'])
            backup = store.backup()
            self.assertTrue(os.path.exists(backup))
            store.set('src', 'chan', ['4097:0:1:0:0:0:0:0:0:0:http://x'])
            self.assertTrue(store.undo_last())
            self.assertEqual(store.get('src', 'chan')['refs'][0], '1:0:1:1:2:3:4:0:0:0:')

    def test_persistent_catalog_cache(self):
        with tempfile.TemporaryDirectory() as td:
            with open(os.path.join(td, 'bouquets.tv'), 'w') as f:
                f.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.test.tv" ORDER BY bouquet\n')
            with open(os.path.join(td, 'userbouquet.test.tv'), 'w') as f:
                f.write('#NAME Test\n#SERVICE 1:0:1:1234:5678:9ABC:00000000:0:0:0:\n#DESCRIPTION Test SAT\n')
            first = channel_mapper.scan_bouquets(td, use_cache=True)
            second = channel_mapper.scan_bouquets(td, use_cache=True)
            self.assertEqual(first, second)
            self.assertEqual(first[0]['service_type'], 'SAT')
            self.assertTrue(os.path.exists(os.path.join(td, '.epgmanager_catalog_cache.json')))

    def test_mapping_coverage(self):
        catalog = [{'ref':'a'}, {'ref':'b'}, {'ref':'c'}]
        cov = channel_mapper.mapping_coverage(catalog, {'a','c'})
        self.assertEqual(cov['mapped'], 2)
        self.assertEqual(cov['percent'], 67)


if __name__ == '__main__':
    unittest.main()
