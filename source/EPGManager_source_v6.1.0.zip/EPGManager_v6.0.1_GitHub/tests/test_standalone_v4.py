# -*- coding: utf-8 -*-
import json
import os
import tempfile

from ..core.channel_mapper import smart_match_channels
from ..core.mapping_store import MappingStore
from ..core.native_importer import parse_xmltv_time, build_import_plan


def test_xmltv_time_with_offset():
    assert parse_xmltv_time("20260809120000 +0100") == parse_xmltv_time("20260809110000 +0000")
    assert parse_xmltv_time("20260809120000 +01:00") == parse_xmltv_time("20260809110000 Z")


def test_smart_mapper_exact_and_fuzzy():
    epg = [{"source_id": "x", "source_name": "X", "channel_id": "bein1", "display_name": "beIN Sports 1 HD", "epg_xml_path": "/tmp/x.xml"}]
    catalog = [
        {"ref": "1:0:1:1:", "name": "beIN Sports 1 FHD", "normalized": "bein sports 1", "bouquet_label": "Nilesat", "bouquet_file": "b.tv"},
        {"ref": "1:0:1:2:", "name": "beIN Sports 2", "normalized": "bein sports 2", "bouquet_label": "Nilesat", "bouquet_file": "b.tv"},
    ]
    result = smart_match_channels(epg, catalog, min_score=82)[0]
    assert result["confidence"] == 100
    assert result["matches"][0]["ref"] == "1:0:1:1:"


def test_manual_mapping_wins():
    with tempfile.TemporaryDirectory() as td:
        store = MappingStore(os.path.join(td, "maps.json"))
        store.set("x", "c1", ["4097:0:1:ABC:"], mode="manual")
        epg = [{"source_id": "x", "source_name": "X", "channel_id": "c1", "display_name": "Unknown", "epg_xml_path": "/tmp/x.xml"}]
        result = smart_match_channels(epg, [], store=store)[0]
        assert result["match_mode"] == "manual"
        assert result["confidence"] == 100
        assert result["matches"][0]["ref"] == "4097:0:1:ABC:"


def test_build_import_plan_from_mapping(monkeypatch):
    from ..core import native_importer as ni
    with tempfile.TemporaryDirectory() as td:
        xml = '''<?xml version="1.0" encoding="UTF-8"?>\n<tv>\n<channel id="c1"><display-name>Channel One</display-name></channel>\n<programme start="20260809120000 +0000" stop="20260809130000 +0000" channel="c1"><title>Test Show</title><desc>Description</desc><category>News</category></programme>\n</tv>'''
        path = os.path.join(td, "test.xml")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(xml)
        monkeypatch.setattr(ni.channel_mapper, "SOURCE_OUTPUT_FILES", {"test.xml": ("x", "X")})
        plan = build_import_plan(td, mapping={"c1": ["1:0:1:1:"]})
        assert plan["events_ready"] == 1
        event = plan["services"]["1:0:1:1:"][0]
        assert event[1] == 3600
        assert event[2] == "Test Show"
        assert event[5] == 0x20


def test_mapping_store_persists():
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, "mapping.json")
        MappingStore(path).set("snrt", "arryadia", ["1:0:1:ABC:"], display_name="Arryadia")
        loaded = MappingStore(path).get("snrt", "arryadia")
        assert loaded["refs"] == ["1:0:1:ABC:"]
        assert loaded["mode"] == "manual"
