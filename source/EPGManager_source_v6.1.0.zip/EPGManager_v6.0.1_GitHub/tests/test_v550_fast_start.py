import os, tempfile, json, time
from EPGManager.core.performance_cache import save_cache, load_cache_fast


def test_fast_cache_loads_recent_payload_without_signature():
    with tempfile.TemporaryDirectory() as d:
        p=os.path.join(d,'cache.json')
        assert save_cache(p, [['x',1,2]], [{'name':'A'}])
        assert load_cache_fast(p, max_age=3600)==[{'name':'A'}]


def test_fast_cache_expires():
    with tempfile.TemporaryDirectory() as d:
        p=os.path.join(d,'cache.json')
        assert save_cache(p, [], [1])
        old=time.time()-7200
        os.utime(p,(old,old))
        assert load_cache_fast(p, max_age=60) is None
