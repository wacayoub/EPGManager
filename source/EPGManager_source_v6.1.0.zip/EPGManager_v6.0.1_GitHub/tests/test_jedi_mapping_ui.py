from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_four_pane_mapping_ui_present():
    text = (ROOT / "ui" / "channel_mapping.py").read_text(encoding="utf-8")
    for token in ('name="bouquets"', 'name="channels"', 'name="sources"', 'name="selections"'):
        assert token in text
    assert "Bouquet" in text
    assert "EPG Source" in text
    assert "EPG Selection" in text
    assert "MANUAL MODE" in text
    assert "Unmap Channel" in text
    assert "Hide Mapped" in text

def test_mapping_assigns_bouquet_service_to_epg_channel():
    text = (ROOT / "ui" / "channel_mapping.py").read_text(encoding="utf-8")
    assert 'self.store.set(epg.get("source_id"), epg.get("channel_id"), [service.get("ref")]' in text
