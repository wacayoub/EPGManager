from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_v590_progress_and_source_ui_present():
    ni=(ROOT/'ui'/'native_import.py').read_text()
    ns=(ROOT/'ui'/'native_sources.py').read_text()
    core=(ROOT/'core'/'native_importer.py').read_text()
    assert 'IMPORTING %d%%' in ni
    assert 'mapped Enigma2 channels' in ni
    assert 'NativeSourceList' in ns
    assert 'mapped providers' in ns
    assert 'progress_cb=None' in core
    assert 'source_stats' in core
