from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def test_native_ai_options_and_save():
    ui=(ROOT/'ui'/'native_import.py').read_text(encoding='utf-8')
    cfg=(ROOT/'core'/'config.py').read_text(encoding='utf-8')
    assert 'AI assisted channel matching' in ui
    assert 'AI confidence threshold' in ui
    assert 'Preflight diagnostics' in ui
    assert 'self._original = self._take_snapshot()' in ui
    assert 'configfile.save()' in ui
    assert 'native_ai_match' in cfg and 'native_ai_threshold' in cfg and 'native_preflight' in cfg

def test_native_import_source_aware_and_compat():
    core=(ROOT/'core'/'native_importer.py').read_text(encoding='utf-8')
    assert 'def _map_key' in core
    assert 'mapping.get(_map_key(_source_id, channel_id))' in core
    assert 'def preflight' in core
    assert 'def _import_events_compat' in core
    assert 'eServiceReference' in core

def test_version_610():
    assert '__version__ = "6.1.0"' in (ROOT/'version.py').read_text(encoding='utf-8')
