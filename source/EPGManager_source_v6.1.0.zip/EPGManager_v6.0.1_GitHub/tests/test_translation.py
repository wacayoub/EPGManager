# -*- coding: utf-8 -*-
"""
tests/test_translation.py

Run with:
    python3 -m unittest EPGManager.tests.test_translation -v
"""

import os
import shutil
import tempfile
import unittest

from ..translators.darija import DarijaTranslator
from ..translators import arabic as arabic_utils


class TestDarijaTranslator(unittest.TestCase):
    def setUp(self):
        # Point the translator's caches at a scratch directory so tests
        # never touch /etc/epgimport/jedi_epg.
        self.tmpdir = tempfile.mkdtemp()
        import EPGManager.translators.darija as darija_mod
        self._orig_cache_path = darija_mod.CACHE_PATH
        self._orig_custom_path = darija_mod.CUSTOM_DICT_PATH
        self._orig_unknown_path = darija_mod.UNKNOWN_SHOWS_PATH
        darija_mod.CACHE_PATH = os.path.join(self.tmpdir, "translation_cache.json")
        darija_mod.CUSTOM_DICT_PATH = os.path.join(self.tmpdir, "custom_dictionary.json")
        darija_mod.UNKNOWN_SHOWS_PATH = os.path.join(self.tmpdir, "unknown_shows.json")

        self.translator = DarijaTranslator(enable_network=False)  # deterministic, offline

    def tearDown(self):
        import EPGManager.translators.darija as darija_mod
        darija_mod.CACHE_PATH = self._orig_cache_path
        darija_mod.CUSTOM_DICT_PATH = self._orig_custom_path
        darija_mod.UNKNOWN_SHOWS_PATH = self._orig_unknown_path
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_official_title_lookup(self):
        result = self.translator.translate("Le Journal")
        self.assertEqual(result, "الأخبار")

    def test_whitelisted_french_kept_as_is(self):
        self.assertTrue(self.translator.is_whitelisted_french("Auto Moto"))
        result = self.translator.translate("Auto Moto", keep_french=True)
        self.assertEqual(result, "Auto Moto")

    def test_tv_prefix_translation(self):
        result = self.translator.translate("Serie Marocaine")
        self.assertTrue(result.startswith("مسلسل مغربي"))

    def test_extract_metadata_season_episode(self):
        base, suffix = self.translator.extract_metadata("Kif El Hal Saison 2 Episode 5")
        self.assertIn("الموسم 2", suffix)
        self.assertIn("الحلقة 5", suffix)
        self.assertNotIn("Saison", base)

    def test_apply_darija_filter(self):
        result = self.translator.apply_darija_filter("ماذا تريد الآن")
        self.assertIn("شنو", result)
        self.assertIn("دابا", result)

    def test_apply_darija_filter_expanded_vocabulary(self):
        """Regression coverage for the 2026-08-09 dictionary expansion."""
        result = self.translator.apply_darija_filter("هل هذا حقيقي أم مستحيل")
        self.assertIn("بصح", result)
        self.assertIn("محال", result)

    def test_no_network_falls_back_to_original_text(self):
        # downloader=None means _translate_google_free must not crash and
        # must return the original text unchanged.
        result = self.translator.translate("Some Untranslated Show Name")
        self.assertIn("Some Untranslated Show Name", result)

    def test_time_strings_pass_through_unchanged(self):
        self.assertEqual(self.translator.translate("20:30"), "20:30")


class TestArabicUtils(unittest.TestCase):
    def test_normalize_text_strips_accents_and_case(self):
        self.assertEqual(arabic_utils.normalize_text("Météo"), "meteo")

    def test_contains_arabic(self):
        self.assertTrue(arabic_utils.contains_arabic("الأخبار"))
        self.assertFalse(arabic_utils.contains_arabic("Le Journal"))

    def test_contains_latin_letters(self):
        self.assertTrue(arabic_utils.contains_latin_letters("Le Journal"))
        self.assertFalse(arabic_utils.contains_latin_letters("الأخبار"))


if __name__ == "__main__":
    unittest.main()

