import os
from pathlib import Path


def test_native_source_store_roundtrip(tmp_path):
    from EPGManager.core.native_source_store import NativeSourceStore
    p = tmp_path / 'sources.json'
    s = NativeSourceStore(str(p))
    s.set_selected(['local_snrt','MOROCCO'])
    s2 = NativeSourceStore(str(p))
    assert s2.get_selected() == {'local_snrt','MOROCCO'}


def test_file_url_download_is_local_copy(tmp_path):
    from EPGManager.core.external_sources import download_source
    src = tmp_path / 'input.xml'
    src.write_text('<tv><channel id="x"><display-name>X</display-name></channel></tv>', encoding='utf-8')
    out = tmp_path / 'out'; out.mkdir()
    item = {'id':'localfile_test','name':'Local file','url':'file://' + str(src)}
    path = download_source(item, str(out), retries=1, timeout=1)
    assert Path(path).exists()
    assert '<tv>' in Path(path).read_text(encoding='utf-8')


def test_import_plan_accepts_source_ids_signature():
    import inspect
    from EPGManager.core.native_importer import build_import_plan
    assert 'source_ids' in inspect.signature(build_import_plan).parameters
