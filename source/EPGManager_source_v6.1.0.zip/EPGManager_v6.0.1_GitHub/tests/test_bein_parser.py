# -*- coding: utf-8 -*-
"""
tests/test_bein_parser.py

Regression tests for the two bugs found and fixed on 2026-08-09:

1. `_parse_events` must try the proven-good positional regex parser FIRST,
   unconditionally - not "only if bs4 is unavailable". Silently preferring
   an untested "nicer" parser just because a library happens to be
   installed, and never falling back when it returns zero results, is
   exactly how this source went from working to "0 events found".
2. The bs4 structural parser must read `data-img` and `live` off the <li>
   tag ITSELF (li.get(...)), not search descendants for them - the
   original working regex (`li\\s+live=...`) proves those attributes live
   directly on the <li>.

Run with:
    python3 -m unittest EPGManager.tests.test_bein_parser -v
"""

import unittest

from ..sources.bein_sports import BeinSportsSource
from ..core.parser import get_soup

# A minimal snippet shaped like real beIN AJAX output: attributes live on
# the <li> tag itself, unquoted class attributes on the <p> tags (matches
# the original script's regex patterns exactly).
#
# NOTE on attribute order: the original script's live-flag regex is
# `r"li\s+live=['\"](\d)['\"]"` - this only matches when `live` is the
# FIRST attribute immediately after `<li` (no other attribute in between).
# That's a real fragility in the regex itself (not something introduced by
# this plugin) - if beIN ever emits `<li data-img="..." live="1">` instead
# of `<li live="1" data-img="...">`, the regex parser silently reports
# every event as non-live. The bs4 fallback parser doesn't have this
# problem (it reads `li.get("live")` regardless of attribute order), which
# is a genuine argument for keeping bs4 as a secondary strategy rather
# than deleting it entirely.
SAMPLE_HTML = """
<ul>
<li live="1" data-img="https://cdn.bein.com/icons/beIN_Sports_1_HD.png">
  <p class=time>20:00&nbsp;-&nbsp;22:00</p>
  <p class=title>Real Madrid - Barcelona</p>
  <p class=format>La Liga</p>
  <p class=description>El Clasico matchday 5</p>
</li>
<li live="0" data-img="https://cdn.bein.com/icons/beIN_Sports_2_HD.png">
  <p class=time>22:00-23:00</p>
  <p class=title>Al Hassad</p>
  <p class=format>Football</p>
  <p class=description>News bulletin</p>
</li>
</ul>
"""


class TestBeinParserRegexPrimary(unittest.TestCase):
    def setUp(self):
        self.source = BeinSportsSource()

    def test_regex_parser_finds_events_in_realistic_markup(self):
        events = self.source._parse_events_regex(SAMPLE_HTML)
        self.assertEqual(len(events), 2)
        self.assertEqual(events[0]["channel"], "beIN_Sports_1_HD")
        self.assertEqual(events[0]["live"], "1")
        self.assertIn("Real Madrid", events[0]["title"])

    def test_bs4_parser_reads_attributes_off_the_li_tag_itself(self):
        soup = get_soup(SAMPLE_HTML)
        events = self.source._parse_events_bs4(soup)
        self.assertEqual(len(events), 2)
        self.assertEqual(events[0]["channel"], "beIN_Sports_1_HD")
        self.assertEqual(events[0]["live"], "1")
        self.assertEqual(events[1]["live"], "0")

    def test_parse_events_tries_regex_before_bs4_and_prefers_a_nonempty_result(self):
        # Even though bs4 IS available in this test environment, the
        # regex path (proven to work against real markup) must be the one
        # that actually returns the events, per the "try primary first,
        # only fall back on empty" contract.
        events = self.source._parse_events(SAMPLE_HTML)
        self.assertEqual(len(events), 2)

    def test_parse_events_falls_back_to_bs4_only_when_regex_finds_nothing(self):
        # Malformed-for-regex-but-still-parseable-by-bs4 markup: attribute
        # values now use double spaces the regex doesn't tolerate, but bs4
        # doesn't care.
        weird_html = SAMPLE_HTML.replace("<p class=time>", "<p  class=time>")
        events = self.source._parse_events(weird_html)
        # Either parser recovering here is acceptable; the key regression
        # guard is that we never end up with zero when at least one
        # strategy can find the events.
        self.assertGreaterEqual(len(events), 1)

    def test_parse_events_returns_empty_list_not_exception_on_garbage(self):
        events = self.source._parse_events("<html><body>nothing here</body></html>")
        self.assertEqual(events, [])

    def test_regex_live_flag_is_order_sensitive_bs4_is_not(self):
        """Documents a real fragility in the ORIGINAL script's live-flag
        regex (not introduced by this plugin): it only matches `live` as
        the first attribute after `<li`. bs4 reads the attribute regardless
        of order. This is why bs4 remains a secondary strategy instead of
        being removed outright."""
        reordered = SAMPLE_HTML.replace(
            'li live="1" data-img=', 'li data-img="PLACEHOLDER" x-live="1" data-img2='
        )
        # Deliberately construct a case where live comes after another
        # attribute - the regex parser cannot see it, bs4 still can.
        html_attr_reordered = (
            '<li data-img="https://cdn.bein.com/icons/beIN_Sports_1_HD.png" live="1">'
            '<p class=time>20:00-22:00</p><p class=title>Test Match</p>'
            '<p class=format>La Liga</p><p class=description>desc</p></li>'
        )
        regex_events = self.source._parse_events_regex(html_attr_reordered)
        soup = get_soup(html_attr_reordered)
        bs4_events = self.source._parse_events_bs4(soup)

        self.assertEqual(regex_events[0]["live"], "0")   # regex misses it (known fragility)
        self.assertEqual(bs4_events[0]["live"], "1")      # bs4 finds it regardless of order


if __name__ == "__main__":
    unittest.main()
