# -*- coding: utf-8 -*-
import datetime
import unittest
from ..core.health import evaluate_health, summarize_health


class TestHealthEvaluation(unittest.TestCase):
    def setUp(self):
        self.today = datetime.date(2026, 8, 9)

    def test_good_one_day_source_is_healthy(self):
        st = {"status": "SUCCESS", "program_count": 20, "days_covered": 1, "date_to": "09/08"}
        self.assertEqual(evaluate_health(st, True, self.today)["level"], "GOOD")

    def test_expired_source_is_failed(self):
        st = {"status": "SUCCESS", "program_count": 20, "days_covered": 1, "date_to": "08/08"}
        result = evaluate_health(st, True, self.today)
        self.assertEqual(result["level"], "FAILED")
        self.assertIn("expired", result["message"].lower())

    def test_zero_programmes_is_failed(self):
        st = {"status": "SUCCESS", "program_count": 0, "days_covered": 1, "date_to": "09/08"}
        self.assertEqual(evaluate_health(st, True, self.today)["level"], "FAILED")

    def test_low_programmes_is_warning(self):
        st = {"status": "SUCCESS", "program_count": 3, "days_covered": 1, "date_to": "09/08"}
        self.assertEqual(evaluate_health(st, True, self.today)["level"], "WARNING")

    def test_disabled_source_is_not_reported_failed(self):
        st = {"status": "FAILED", "program_count": 0}
        self.assertEqual(evaluate_health(st, False, self.today)["level"], "DISABLED")

    def test_summary_counts_levels(self):
        statuses = [
            {"id": "a", "status": "SUCCESS", "program_count": 10, "days_covered": 1, "date_to": "09/08"},
            {"id": "b", "status": "FAILED", "program_count": 0},
        ]
        summary = summarize_health(statuses, {"a": True, "b": True})
        self.assertEqual(summary["GOOD"], 1)
        self.assertEqual(summary["FAILED"], 1)


if __name__ == "__main__":
    unittest.main()
