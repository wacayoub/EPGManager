# -*- coding: utf-8 -*-
"""
tests/test_xmltv.py

Run with (from the directory that CONTAINS EPGManager/):
    python3 -m unittest EPGManager.tests.test_xmltv -v
"""

import os
import shutil
import tempfile
import unittest
from datetime import datetime, timedelta, timezone

from ..core.xmltv import XMLTVBuilder, Programme
from ..core.validation import validate_xmltv_string


def _dt(hour, minute=0, day=1):
    return datetime(2026, 8, day, hour, minute, tzinfo=timezone(timedelta(hours=1)))


class TestXMLTVBuilder(unittest.TestCase):
    def setUp(self):
        self.builder = XMLTVBuilder(generator_name="Test")
        self.builder.add_channel("CH1", "Channel One")

    def test_stop_time_from_next_start(self):
        self.builder.add_programme(Programme("CH1", _dt(20), "Show A"))
        self.builder.add_programme(Programme("CH1", _dt(21), "Show B"))
        xml_text = self.builder.to_xml_string()
        self.assertIn('start="20260801200000 +0100"', xml_text)
        self.assertIn('stop="20260801210000 +0100"', xml_text)

    def test_stop_time_default_duration_for_last_slot(self):
        self.builder.add_programme(Programme("CH1", _dt(23), "Late Show"))
        xml_text = self.builder.to_xml_string()
        # default duration is 60 minutes -> stop should be 00:00 next day
        self.assertIn('stop="20260802000000 +0100"', xml_text)

    def test_midnight_crossing_program(self):
        self.builder.add_programme(Programme("CH1", _dt(23, 30), "Late show"))
        self.builder.add_programme(Programme("CH1", _dt(0, 30, day=2), "After midnight"))
        xml_text = self.builder.to_xml_string()
        self.assertIn('start="20260801233000 +0100"', xml_text)
        self.assertIn('stop="20260802003000 +0100"', xml_text)

    def test_deduplication(self):
        self.builder.add_programme(Programme("CH1", _dt(20), "Show A"))
        self.builder.add_programme(Programme("CH1", _dt(20), "Show A"))  # exact dup
        self.builder.add_programme(Programme("CH1", _dt(20), "Show B"))  # same time, diff title -> kept
        xml_text = self.builder.to_xml_string()
        self.assertEqual(xml_text.count("<programme "), 2)

    def test_chronological_sort(self):
        self.builder.add_programme(Programme("CH1", _dt(22), "Later"))
        self.builder.add_programme(Programme("CH1", _dt(20), "Earlier"))
        xml_text = self.builder.to_xml_string()
        self.assertLess(xml_text.index("Earlier"), xml_text.index("Later"))

    def test_explicit_stop_time_is_respected(self):
        explicit_stop = _dt(23, 45)
        self.builder.add_programme(Programme("CH1", _dt(20), "Movie", stop=explicit_stop))
        self.builder.add_programme(Programme("CH1", _dt(20, 30), "Should not shorten the movie"))
        xml_text = self.builder.to_xml_string()
        self.assertIn('stop="20260801234500 +0100"', xml_text)

    def test_channel_auto_registered_from_programme(self):
        self.builder.add_programme(Programme("UNSEEN_CHANNEL", _dt(20), "Show"))
        xml_text = self.builder.to_xml_string()
        self.assertIn('<channel id="UNSEEN_CHANNEL">', xml_text)

    def test_get_date_range_empty(self):
        days, from_d, to_d = self.builder.get_date_range()
        self.assertEqual(days, 0)
        self.assertIsNone(from_d)
        self.assertIsNone(to_d)

    def test_get_date_range_single_day(self):
        self.builder.add_programme(Programme("CH1", _dt(20), "A"))
        self.builder.add_programme(Programme("CH1", _dt(22), "B"))
        days, from_d, to_d = self.builder.get_date_range()
        self.assertEqual(days, 1)
        self.assertEqual(from_d, to_d)

    def test_get_date_range_multiple_days(self):
        self.builder.add_programme(Programme("CH1", _dt(20, day=1), "A"))
        self.builder.add_programme(Programme("CH1", _dt(20, day=3), "B"))
        self.builder.add_programme(Programme("CH1", _dt(20, day=5), "C"))
        days, from_d, to_d = self.builder.get_date_range()
        self.assertEqual(days, 3)  # 3 distinct calendar dates, not a range span
        self.assertEqual((to_d - from_d).days, 4)

    def test_xml_is_valid_and_escapes_entities(self):
        self.builder.add_programme(Programme("CH1", _dt(20), "Tom & Jerry <Special>"))
        xml_text = self.builder.to_xml_string()
        result = validate_xmltv_string(xml_text, min_programs=1)
        self.assertTrue(result.ok, result.errors)
        self.assertNotIn("<Special>", xml_text)  # must be escaped, not raw
        self.assertIn("&amp;", xml_text)


class TestValidationAndAtomicSave(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.output_path = os.path.join(self.tmpdir, "test.xml")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_empty_result_does_not_overwrite_good_file(self):
        # First: write a good file.
        good_builder = XMLTVBuilder()
        good_builder.add_channel("CH1", "Channel One")
        good_builder.add_programme(Programme("CH1", _dt(20), "Good Show"))
        result = good_builder.save(self.output_path, min_programs=1)
        self.assertTrue(result.ok)

        with open(self.output_path, "r", encoding="utf-8") as f:
            good_content = f.read()

        # Second: an empty builder should REFUSE to overwrite it.
        empty_builder = XMLTVBuilder()
        empty_builder.add_channel("CH1", "Channel One")
        result2 = empty_builder.save(self.output_path, min_programs=1)
        self.assertFalse(result2.ok)

        with open(self.output_path, "r", encoding="utf-8") as f:
            after_content = f.read()

        self.assertEqual(good_content, after_content, "Good file must be left untouched")

    def test_backup_file_created_on_successful_overwrite(self):
        b1 = XMLTVBuilder()
        b1.add_channel("CH1", "Channel One")
        b1.add_programme(Programme("CH1", _dt(20), "First"))
        b1.save(self.output_path, min_programs=1)

        b2 = XMLTVBuilder()
        b2.add_channel("CH1", "Channel One")
        b2.add_programme(Programme("CH1", _dt(21), "Second"))
        b2.save(self.output_path, min_programs=1)

        self.assertTrue(os.path.exists(self.output_path + ".bak"))
        with open(self.output_path + ".bak", "r", encoding="utf-8") as f:
            self.assertIn("First", f.read())


class TestValidationEdgeCases(unittest.TestCase):
    def test_malformed_xml_fails_validation(self):
        result = validate_xmltv_string("<tv><channel id='x'></tv>")  # mismatched tag
        self.assertFalse(result.ok)

    def test_wrong_root_element_fails(self):
        result = validate_xmltv_string("<notatv></notatv>")
        self.assertFalse(result.ok)

    def test_min_programs_enforced(self):
        xml = '<tv><channel id="a"><display-name>A</display-name></channel></tv>'
        result = validate_xmltv_string(xml, min_programs=1)
        self.assertFalse(result.ok)


if __name__ == "__main__":
    unittest.main()
