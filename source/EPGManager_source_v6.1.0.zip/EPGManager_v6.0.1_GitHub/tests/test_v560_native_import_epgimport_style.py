from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def test_native_import_epgimport_style_screen_and_controls():
    text = (ROOT / 'ui' / 'native_import.py').read_text(encoding='utf-8')
    for token in ('EPG Import Configuration', 'Automatic import EPG', 'Automatic start time',
                  'Delete current EPG before import', 'Load long descriptions up to X days',
                  'Manual', 'Sources'):
        assert token in text

def test_native_import_options_wired_to_engine():
    core = (ROOT / 'core' / 'native_importer.py').read_text(encoding='utf-8')
    mgr = (ROOT / 'core' / 'manager.py').read_text(encoding='utf-8')
    assert 'only_iptv=False' in core
    assert 'clear_before_import=False' in core
    assert 'long_desc_days=5' in core
    assert '_native_import_after_update_if_enabled' in mgr
