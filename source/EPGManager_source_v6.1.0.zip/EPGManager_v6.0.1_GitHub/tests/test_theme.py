# -*- coding: utf-8 -*-
"""
tests/test_theme.py

Run with:
    python3 -m unittest EPGManager.tests.test_theme -v
"""

import unittest

from ..ui import theme


class TestKeyBarSkin(unittest.TestCase):
    def test_produces_two_widgets(self):
        snippet = theme.key_bar_skin("key_red", 20, 660, 280, 36, theme.BTN_RED)
        self.assertEqual(snippet.count("<widget"), 2)

    def test_bar_widget_uses_the_given_color(self):
        snippet = theme.key_bar_skin("key_red", 20, 660, 280, 36, theme.BTN_RED)
        self.assertIn('name="key_red_bar"', snippet)
        self.assertIn('backgroundColor="%s"' % theme.BTN_RED, snippet)

    def test_text_widget_is_offset_past_the_bar(self):
        snippet = theme.key_bar_skin("key_red", 20, 660, 280, 36, theme.BTN_RED)
        self.assertIn('name="key_red"', snippet)
        # text widget x position must be greater than the bar's x + bar width
        self.assertIn('position="50,660"', snippet)  # 20 + 9(bar) + 21(gap)

    def test_narrow_width_does_not_produce_negative_size(self):
        # Even a pathologically narrow width must not crash or emit a
        # negative widget size (which Enigma2's skin engine would reject).
        snippet = theme.key_bar_skin("key_x", 0, 0, 10, 36, theme.BTN_RED)
        self.assertNotIn('size="-', snippet)

    def test_output_is_valid_enough_xml_fragment(self):
        snippet = theme.key_bar_skin("key_green", 340, 660, 300, 36, theme.BTN_GREEN)
        # Every opened <widget tag must be self-closed with />
        self.assertEqual(snippet.count("<widget"), snippet.count("/>"))


if __name__ == "__main__":
    unittest.main()
