from pathlib import Path

def test_logs_screen_does_not_bind_optional_scrolllabel_home_end_directly():
    text = (Path(__file__).resolve().parents[1] / "ui" / "screens.py").read_text()
    assert 'self["text"].home' not in text
    assert 'self["text"].end' not in text
    assert '"0": self._scroll_top' in text
    assert '"9": self._scroll_bottom' in text

def test_blue_open_is_guarded():
    text = (Path(__file__).resolve().parents[1] / "ui" / "main.py").read_text()
    assert 'def open_logs(self):' in text
    assert 'Unable to open Logs / About' in text
