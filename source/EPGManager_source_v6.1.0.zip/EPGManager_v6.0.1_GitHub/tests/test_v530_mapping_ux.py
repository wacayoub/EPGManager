from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_v530_mapping_ux_features_present():
    text = (ROOT / "ui" / "channel_mapping.py").read_text(encoding="utf-8")
    assert "ChannelPaneList" in text
    assert "mapped.png" in text
    assert "setSelectionEnable(i <= self.focus)" in text
    assert "_jump_to_best_source_for_current_channel" in text
    assert "search_channel" in text
    assert "preview_three_programmes" in text
    assert "undo_last_mapping" in text
    assert "[SAT]" not in text
    assert "[IPTV]" not in text
    assert "  [LOCAL]" not in text

def test_mapped_icon_is_packaged():
    assert (ROOT / "icons" / "mapped.png").exists()
