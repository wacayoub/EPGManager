from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_source_rows_use_full_width_base_band():
    text = (ROOT / "ui" / "widgets.py").read_text()
    assert "size=(LIST_WIDTH - 4, ROW_HEIGHT - 8)" in text
    assert "RULE_SOFT_INT" in text

def test_main_screen_has_no_generic_side_icon():
    text = (ROOT / "ui" / "main.py").read_text()
    assert 'name="side_icon"' not in text
    assert 'self["side_icon"]' not in text
    assert 'SOURCE DETAILS' in text
