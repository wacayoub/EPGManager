# -*- coding: utf-8 -*-
"""
tests/test_epgimport_export.py

Run with:
    python3 -m unittest EPGManager.tests.test_epgimport_export -v
"""

import os
import shutil
import tempfile
import unittest
from xml.etree import ElementTree as ET

from ..core.epgimport_export import build_sourcexml, save_sourcexml


def _matched_channel(epg_xml_path, channel_id, matches):
    return {
        "source_id": "chada_2m", "source_name": "2M / Chada",
        "epg_xml_path": epg_xml_path, "channel_id": channel_id,
        "display_name": channel_id, "matches": matches, "satellites": [],
    }


class TestBuildSourceXml(unittest.TestCase):
    def test_unmatched_channels_are_excluded(self):
        channels = [
            _matched_channel("/etc/epgimport/jedi_epg/2M_Chada.xml", "2M", []),
        ]
        xml_text, total_channels, total_refs = build_sourcexml(channels)
        self.assertEqual(total_channels, 0)
        self.assertEqual(total_refs, 0)
        self.assertNotIn("2M", xml_text)

    def test_matched_channel_produces_channel_entries(self):
        channels = [
            _matched_channel("/etc/epgimport/jedi_epg/2M_Chada.xml", "2M", [
                {"ref": "1:0:1:1000:1:1:0:0:0:0:", "name": "2M Maroc HD", "bouquet_label": "Nilesat 7W"},
                {"ref": "1:0:1:2000:1:1:0:0:0:0:", "name": "2M", "bouquet_label": "Astra 19E"},
            ]),
        ]
        xml_text, total_channels, total_refs = build_sourcexml(channels)
        self.assertEqual(total_channels, 1)
        self.assertEqual(total_refs, 2)

        root = ET.fromstring(xml_text)
        chan_els = root.findall(".//channel")
        self.assertEqual(len(chan_els), 2)
        for el in chan_els:
            self.assertEqual(el.get("id"), "2M")
        refs = sorted(el.text for el in chan_els)
        self.assertEqual(refs, sorted(["1:0:1:1000:1:1:0:0:0:0:", "1:0:1:2000:1:1:0:0:0:0:"]))

    def test_multiple_source_files_get_separate_source_blocks(self):
        channels = [
            _matched_channel("/etc/epgimport/jedi_epg/2M_Chada.xml", "2M", [
                {"ref": "ref1", "name": "2M", "bouquet_label": "Nilesat 7W"},
            ]),
            _matched_channel("/etc/epgimport/jedi_epg/snrt.xml", "AlAoula", [
                {"ref": "ref2", "name": "Al Aoula", "bouquet_label": "Nilesat 7W"},
            ]),
        ]
        xml_text, total_channels, total_refs = build_sourcexml(channels)
        root = ET.fromstring(xml_text)
        self.assertEqual(len(root.findall("source")), 2)

    def test_output_is_valid_xml(self):
        channels = [
            _matched_channel("/etc/epgimport/jedi_epg/2M_Chada.xml", "2M & Co", [
                {"ref": "ref1", "name": "2M", "bouquet_label": "Nilesat 7W"},
            ]),
        ]
        xml_text, _, _ = build_sourcexml(channels)
        # Must not raise - and the entity must be escaped, not raw.
        ET.fromstring(xml_text)
        self.assertNotIn("2M & Co", xml_text)
        self.assertIn("2M &amp; Co", xml_text)


class TestSaveSourceXml(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.output_path = os.path.join(self.tmpdir, "epgmanager.sources.xml")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_writes_file_to_disk(self):
        channels = [
            _matched_channel("/etc/epgimport/jedi_epg/2M_Chada.xml", "2M", [
                {"ref": "ref1", "name": "2M", "bouquet_label": "Nilesat 7W"},
            ]),
        ]
        path, total_channels, total_refs = save_sourcexml(channels, output_path=self.output_path)
        self.assertTrue(os.path.exists(path))
        self.assertEqual(total_channels, 1)
        self.assertEqual(total_refs, 1)


if __name__ == "__main__":
    unittest.main()
