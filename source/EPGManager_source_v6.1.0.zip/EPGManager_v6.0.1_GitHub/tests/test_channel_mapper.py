# -*- coding: utf-8 -*-
"""
tests/test_channel_mapper.py

Run with:
    python3 -m unittest EPGManager.tests.test_channel_mapper -v
"""

import os
import shutil
import tempfile
import unittest

from ..core import channel_mapper as cm

NILESAT_BOUQUET = """#NAME Nilesat 7W
#SERVICE 1:0:1:1000:1:1:0:0:0:0:
#DESCRIPTION 2M Maroc HD
#SERVICE 1:0:1:1001:1:1:0:0:0:0:
#DESCRIPTION Chada TV
#SERVICE 1:64:0:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.somethingelse.tv" ORDER BY bouquet
"""

ASTRA_BOUQUET = """#NAME Astra 19E
#SERVICE 1:0:1:2000:1:1:0:0:0:0:
#DESCRIPTION 2M
#SERVICE 1:0:1:2001:1:1:0:0:0:0:
#DESCRIPTION Some Other Channel
"""

HOTBIRD_BOUQUET = """#NAME Hotbird 13E
#SERVICE 1:0:1:3000:1:1:0:0:0:0:
#DESCRIPTION Arryadia HD FHD
"""

SAMPLE_XMLTV = """<?xml version="1.0" encoding="UTF-8"?>
<tv>
  <channel id="2M"><display-name>2M</display-name></channel>
  <channel id="Chada TV"><display-name>Chada TV</display-name></channel>
</tv>
"""


class TestNormalizeName(unittest.TestCase):
    def test_strips_hd_suffix(self):
        self.assertEqual(cm.normalize_name("Arryadia HD"), "arryadia")

    def test_strips_diacritics_and_case(self):
        self.assertEqual(cm.normalize_name("Médi1 TV"), "medi1")

    def test_empty_input(self):
        self.assertEqual(cm.normalize_name(""), "")
        self.assertEqual(cm.normalize_name(None), "")


class TestScanBouquets(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self._write("userbouquet.nilesat_7w.tv", NILESAT_BOUQUET)
        self._write("userbouquet.astra_19e.tv", ASTRA_BOUQUET)
        self._write("userbouquet.hotbird_13e.tv", HOTBIRD_BOUQUET)
        # A non-bouquet file that must be ignored.
        self._write("bouquets.tv", "#NAME Bouquets\n#SERVICE 1:64:...\n")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _write(self, name, content):
        with open(os.path.join(self.tmpdir, name), "w", encoding="utf-8") as f:
            f.write(content)

    def test_scans_all_userbouquet_files(self):
        catalog = cm.scan_bouquets(self.tmpdir)
        names = [e["name"] for e in catalog]
        self.assertIn("2M Maroc HD", names)
        self.assertIn("Chada TV", names)
        self.assertIn("2M", names)
        self.assertIn("Arryadia HD FHD", names)

    def test_ignores_from_bouquet_redirects(self):
        catalog = cm.scan_bouquets(self.tmpdir)
        # 2 (Nilesat) + 2 (Astra) + 1 (Hotbird) = 5 real services; the
        # FROM BOUQUET redirect line in NILESAT_BOUQUET must not add a 6th.
        self.assertEqual(len(catalog), 5)

    def test_bouquet_label_from_name_header(self):
        catalog = cm.scan_bouquets(self.tmpdir)
        nilesat_entries = [e for e in catalog if e["name"] == "2M Maroc HD"]
        self.assertEqual(nilesat_entries[0]["bouquet_label"], "Nilesat 7W")

    def test_empty_directory_returns_empty_list(self):
        empty_dir = tempfile.mkdtemp()
        try:
            self.assertEqual(cm.scan_bouquets(empty_dir), [])
        finally:
            shutil.rmtree(empty_dir, ignore_errors=True)

    def test_nonexistent_directory_does_not_raise(self):
        self.assertEqual(cm.scan_bouquets("/nonexistent/path/xyz"), [])


class TestListEpgChannels(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        with open(os.path.join(self.tmpdir, "2M_Chada.xml"), "w", encoding="utf-8") as f:
            f.write(SAMPLE_XMLTV)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_reads_channels_from_generated_xmltv(self):
        channels = cm.list_epg_channels(self.tmpdir)
        ids = [c["channel_id"] for c in channels]
        self.assertIn("2M", ids)
        self.assertIn("Chada TV", ids)

    def test_missing_files_are_skipped_not_errored(self):
        empty_dir = tempfile.mkdtemp()
        try:
            self.assertEqual(cm.list_epg_channels(empty_dir), [])
        finally:
            shutil.rmtree(empty_dir, ignore_errors=True)


class TestMatchChannels(unittest.TestCase):
    def setUp(self):
        self.bouquet_dir = tempfile.mkdtemp()
        for name, content in [
            ("userbouquet.nilesat_7w.tv", NILESAT_BOUQUET),
            ("userbouquet.astra_19e.tv", ASTRA_BOUQUET),
            ("userbouquet.hotbird_13e.tv", HOTBIRD_BOUQUET),
        ]:
            with open(os.path.join(self.bouquet_dir, name), "w", encoding="utf-8") as f:
                f.write(content)
        self.catalog = cm.scan_bouquets(self.bouquet_dir)

    def tearDown(self):
        shutil.rmtree(self.bouquet_dir, ignore_errors=True)

    def test_channel_found_across_multiple_satellites(self):
        epg_channels = [{
            "source_id": "chada_2m", "source_name": "2M / Chada",
            "epg_xml_path": "/fake/2M_Chada.xml",
            "channel_id": "2M", "display_name": "2M",
        }]
        results = cm.match_channels(epg_channels, self.catalog)
        self.assertEqual(len(results), 1)
        r = results[0]
        self.assertGreaterEqual(len(r["matches"]), 2)  # Nilesat's "2M Maroc HD" + Astra's "2M"
        self.assertIn("Nilesat 7W", r["satellites"])
        self.assertIn("Astra 19E", r["satellites"])

    def test_unmatched_channel_returns_empty_matches(self):
        epg_channels = [{
            "source_id": "medi1tv", "source_name": "Medi1 TV",
            "epg_xml_path": "/fake/medi1tv_ar.xml",
            "channel_id": "MEDI1TV_AR.ma", "display_name": "Medi1 TV Arabic - Totally Unmatched Name",
        }]
        results = cm.match_channels(epg_channels, self.catalog)
        self.assertEqual(results[0]["matches"], [])
        self.assertEqual(results[0]["satellites"], [])

    def test_arryadia_matches_despite_extra_qualifiers(self):
        epg_channels = [{
            "source_id": "arryadia", "source_name": "Arryadia",
            "epg_xml_path": "/fake/arryadia_snrt.xml",
            "channel_id": "Arryadia_HD", "display_name": "Arryadia HD",
        }]
        results = cm.match_channels(epg_channels, self.catalog)
        self.assertGreaterEqual(len(results[0]["matches"]), 1)
        self.assertIn("Hotbird 13E", results[0]["satellites"])


if __name__ == "__main__":
    unittest.main()
