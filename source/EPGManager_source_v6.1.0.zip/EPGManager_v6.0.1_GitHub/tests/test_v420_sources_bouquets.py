# -*- coding: utf-8 -*-
import os

from ..core import channel_mapper, external_sources


def test_external_catalog_contains_requested_groups():
    names = {x['name'] for x in external_sources.SOURCES}
    assert 'PALESTINE1' in names
    assert 'QATAR6' in names
    assert 'Rytec-News' in names
    assert 'Rytec-UK-Sports-Movies' in names
    assert 'USA' in names
    assert 'New_Zealand' in names
    assert len(names) >= 110


def test_list_bouquets_includes_nested_and_unreferenced(tmp_path):
    (tmp_path / 'bouquets.tv').write_text('#NAME Bouquets\n#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.main.tv" ORDER BY bouquet\n')
    (tmp_path / 'userbouquet.main.tv').write_text('#NAME MAIN\n#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.sub.tv" ORDER BY bouquet\n#SERVICE 1:0:1:1:2:3:4:0:0:0:\n#DESCRIPTION Main Channel\n')
    (tmp_path / 'userbouquet.sub.tv').write_text('#NAME SUB\n#SERVICE 1:0:1:5:6:7:8:0:0:0:\n#DESCRIPTION Sub Channel\n')
    (tmp_path / 'userbouquet.extra.tv').write_text('#NAME EXTRA\n')
    bouquets = channel_mapper.list_bouquets(str(tmp_path))
    labels = [x['bouquet_label'] for x in bouquets]
    assert labels[:2] == ['MAIN', 'SUB']
    assert 'EXTRA' in labels
    assert next(x for x in bouquets if x['bouquet_label'] == 'SUB')['parent'] == 'MAIN'
    catalog = channel_mapper.scan_bouquets(str(tmp_path))
    assert {x['name'] for x in catalog} == {'Main Channel', 'Sub Channel'}
