# -*- coding: utf-8 -*-
"""
core/timezone_manager.py

Single source of truth for Morocco (Africa/Casablanca) time handling.

Background
----------
Morocco does NOT use a fixed UTC+1 offset. Since 2018 the government pauses
its permanent DST (UTC+1) during (roughly) the month of Ramadan, reverting to
UTC+0 for that window, with the exact start/end dates announced yearly and
tied to the Hijri calendar rather than a fixed Gregorian date.

Two of the six original scripts got this wrong or fragile:
  - 7.ARRYADIA.py hardcoded `timezone(timedelta(hours=1))` - always wrong
    during the Ramadan pause.
  - 1.MEDI1TV.py / 3.SNRT.py / 5.ALMAJD.py rely on pytz's tzdata for
    Africa/Casablanca, which is correct IF the box's tzdata package is
    up to date - but Enigma2 images can ship stale tzdata for years.
  - 2.2M_CHADA.py had the best answer: it cross-checks the Hijri calendar
    via api.aladhan.com and falls back to pytz's own offset if that API is
    unreachable. That logic is promoted here and made available to every
    source module, with the result cached to disk (not just memory) so a
    plugin restart doesn't re-hit the network needlessly.

Usage
-----
    from core.timezone_manager import TimezoneManager
    tzm = TimezoneManager()
    aware_dt = tzm.localize(naive_datetime)
    xmltv_str = tzm.format_xmltv(aware_dt)
"""

import json
import os
import re
import time
from datetime import datetime, timedelta

from .logger import get_logger

log = get_logger(__name__)

_TZ_NAME = "Africa/Casablanca"

# Cache file so the Ramadan cross-check survives restarts and repeated runs
# within the same day don't hit the network repeatedly.
_HIJRI_CACHE_PATH = "/etc/epgimport/jedi_epg/.hijri_offset_cache.json"
_HIJRI_API = "http://api.aladhan.com/v1/gToH?date={date}"

# --------------------------------------------------------------------------
# Backend timezone object: prefer pytz, fall back to zoneinfo (3.9+), fall
# back to a fixed offset ONLY as an absolute last resort (with a loud
# warning, since that reintroduces the Ramadan bug on purpose as a
# last-ditch "still boot the plugin" measure).
# --------------------------------------------------------------------------
try:
    import pytz
    _BACKEND = "pytz"
except ImportError:
    pytz = None
    try:
        from zoneinfo import ZoneInfo  # Python 3.9+
        _BACKEND = "zoneinfo"
    except ImportError:
        ZoneInfo = None
        _BACKEND = "fixed"


class TimezoneManager(object):
    def __init__(self, use_hijri_crosscheck=True, http_timeout=5):
        self.use_hijri_crosscheck = use_hijri_crosscheck
        self.http_timeout = http_timeout
        self._tz = self._build_tz()
        self._hijri_cache = self._load_hijri_cache()
        log.info("TimezoneManager backend=%s hijri_crosscheck=%s",
                 _BACKEND, self.use_hijri_crosscheck)

    # -- backend setup ----------------------------------------------------
    def _build_tz(self):
        if _BACKEND == "pytz":
            return pytz.timezone(_TZ_NAME)
        if _BACKEND == "zoneinfo":
            return ZoneInfo(_TZ_NAME)
        log.warning(
            "Neither pytz nor zoneinfo available - falling back to a FIXED "
            "UTC+1 offset. This WILL be wrong during the Ramadan DST pause. "
            "Install python3-pytz as soon as possible."
        )
        return None  # signals fixed-offset mode

    # -- public API ---------------------------------------------------------
    def now(self):
        """Current aware datetime in Casablanca time."""
        if _BACKEND == "pytz":
            return datetime.now(pytz.utc).astimezone(self._tz)
        if _BACKEND == "zoneinfo":
            from datetime import timezone as _tz_utc
            return datetime.now(_tz_utc.utc).astimezone(self._tz)
        return datetime.utcnow() + timedelta(hours=self._fixed_offset_hint())

    def localize(self, naive_dt):
        """Attach the correct Casablanca offset to a naive datetime."""
        if _BACKEND == "pytz":
            aware = self._tz.localize(naive_dt)
            aware = self._maybe_crosscheck(naive_dt, aware)
            return aware
        if _BACKEND == "zoneinfo":
            aware = naive_dt.replace(tzinfo=self._tz)
            aware = self._maybe_crosscheck(naive_dt, aware)
            return aware

        # fixed-offset last resort
        from datetime import timezone as _tz_fixed
        offset_hours = self._fixed_offset_hint(naive_dt)
        return naive_dt.replace(tzinfo=_tz_fixed(timedelta(hours=offset_hours)))

    def format_xmltv(self, aware_dt):
        """Format an aware datetime as XMLTV expects: YYYYMMDDHHMMSS +ZZZZ"""
        return aware_dt.strftime("%Y%m%d%H%M%S %z")

    def today_midnight(self):
        n = self.now()
        return n.replace(hour=0, minute=0, second=0, microsecond=0)

    def from_timestamp(self, epoch_seconds):
        """Convert a POSIX timestamp (as stored by time.time() /
        config.set_last_update()) into an aware Casablanca-local datetime.
        Uses the timezone object's own .astimezone() conversion, which
        correctly resolves the right UTC offset for that specific instant
        (including across a Ramadan DST-pause boundary) rather than
        assuming "now"'s offset also applied at that past moment."""
        from datetime import datetime, timezone as _tz_utc
        utc_dt = datetime.fromtimestamp(epoch_seconds, _tz_utc.utc)
        if self._tz is not None:
            return utc_dt.astimezone(self._tz)
        # fixed-offset last resort backend
        offset_hours = self._fixed_offset_hint(utc_dt.replace(tzinfo=None))
        from datetime import timedelta
        return utc_dt.astimezone(_tz_utc(timedelta(hours=offset_hours)))

    # -- Ramadan cross-check (ported & generalized from 2M/Chada script) --
    def _maybe_crosscheck(self, naive_dt, aware_dt):
        """If enabled, verify the pytz/zoneinfo-derived offset against the
        Hijri calendar and correct it if they disagree. Only overrides when
        the API is reachable; otherwise trusts the tzdata-derived offset
        unchanged (same fallback philosophy as the original 2M/Chada
        script)."""
        if not self.use_hijri_crosscheck:
            return aware_dt

        try:
            expected_offset = self._get_ramadan_expected_offset(naive_dt)
        except Exception as e:
            log.debug("Hijri cross-check skipped: %s", e)
            return aware_dt

        if expected_offset is None:
            return aware_dt

        current_offset = int(aware_dt.utcoffset().total_seconds() / 3600)
        if current_offset != expected_offset:
            log.warning(
                "Local tzdata says UTC%+d for %s but Hijri cross-check "
                "expects UTC%+d (Ramadan pause). Overriding with the "
                "Hijri-derived offset.",
                current_offset, naive_dt.date(), expected_offset,
            )
            from datetime import timezone as _tz_fixed
            return naive_dt.replace(tzinfo=_tz_fixed(timedelta(hours=expected_offset)))

        return aware_dt

    def _get_ramadan_expected_offset(self, naive_dt):
        """Return 0 (Ramadan pause) or 1 (normal DST) for the given date, or
        None if undetermined. Uses a disk+memory cache and the aladhan.com
        Hijri conversion API, exactly like the original 2M/Chada script's
        get_current_marocco_offset(), but shared across all sources."""
        date_key = naive_dt.strftime("%d-%m-%Y")
        if date_key in self._hijri_cache:
            return self._hijri_cache[date_key]

        try:
            import requests
            url = _HIJRI_API.format(date=date_key)
            resp = requests.get(url, timeout=self.http_timeout)
            if resp.status_code == 200:
                data = resp.json()
                hijri_month = int(data["data"]["hijri"]["month"]["number"])
                hijri_day = int(data["data"]["hijri"]["day"])

                is_ramadan_period = False
                if hijri_month == 9:
                    is_ramadan_period = True
                elif hijri_month == 8 and hijri_day >= 24:
                    is_ramadan_period = True
                elif hijri_month == 10 and hijri_day <= 6:
                    is_ramadan_period = True

                offset = 0 if is_ramadan_period else 1
                self._hijri_cache[date_key] = offset
                self._save_hijri_cache()
                return offset
        except Exception as e:
            log.debug("Hijri API unreachable (%s), trusting local tzdata for %s", e, date_key)

        return None  # undetermined -> caller keeps the tzdata-derived offset

    def _fixed_offset_hint(self, naive_dt=None):
        """Best-effort guess used ONLY when neither pytz nor zoneinfo exist.
        Tries the Hijri cache/API too, defaults to +1 (Morocco standard)."""
        naive_dt = naive_dt or datetime.utcnow()
        try:
            offset = self._get_ramadan_expected_offset(naive_dt)
            if offset is not None:
                return offset
        except Exception:
            pass
        return 1

    # -- disk cache ---------------------------------------------------------
    def _load_hijri_cache(self):
        try:
            if os.path.exists(_HIJRI_CACHE_PATH):
                with open(_HIJRI_CACHE_PATH, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return {}

    def _save_hijri_cache(self):
        try:
            os.makedirs(os.path.dirname(_HIJRI_CACHE_PATH), exist_ok=True)
            # Keep the cache small: drop entries older than ~40 days.
            cutoff = datetime.now() - timedelta(days=40)
            pruned = {}
            for k, v in self._hijri_cache.items():
                try:
                    d = datetime.strptime(k, "%d-%m-%Y")
                    if d >= cutoff:
                        pruned[k] = v
                except Exception:
                    continue
            self._hijri_cache = pruned
            with open(_HIJRI_CACHE_PATH, "w", encoding="utf-8") as f:
                json.dump(self._hijri_cache, f)
        except Exception as e:
            log.debug("Could not persist Hijri offset cache: %s", e)
