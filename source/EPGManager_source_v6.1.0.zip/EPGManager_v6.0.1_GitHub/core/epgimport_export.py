# -*- coding: utf-8 -*-
"""
core/epgimport_export.py

Writes an EPG-Importer-style sourcexml file so the physical service
references discovered by core/channel_mapper.py get wired to the right
XMLTV <channel id>, without needing to hand-edit anything inside
EPG-Importer itself.

Honesty note: EPG-Importer / Jedi EPG Importer's exact sourcexml handling
has varied a bit across forks and versions over the years. The format
generated here follows the widely-documented structure (a <sources> root,
one <source type="gen_xmltv"> per XMLTV file, a <url> pointing at the
local file, and <channel id="xmltv-id">servicereference</channel> entries
inside). After generating this file you will likely still need to open
EPG-Importer's own Settings screen once and enable/select this source list
(exactly what the "1: Open EPG-Importer" button on the dashboard is for) -
this plugin cannot silently register itself inside another plugin's
internal config without risking corrupting it.
"""

import os
from xml.etree import ElementTree as ET

from .logger import get_logger
from .utils import indent_xml, atomic_write

log = get_logger(__name__)

OUTPUT_PATH = "/etc/epgimport/epgmanager.sources.xml"


def build_sourcexml(matched_channels, description="EPG Manager (auto-generated)"):
    """matched_channels: the output of core.channel_mapper.match_channels()
    - a list of dicts with epg_xml_path/channel_id/matches. Only channels
    with at least one match are written (unmatched channels are reported
    separately by the UI, not silently included with an empty mapping)."""
    root = ET.Element("sources")

    # Group by source XMLTV file, since each needs its own <source> block.
    by_file = {}
    for ch in matched_channels:
        if not ch.get("matches"):
            continue
        by_file.setdefault(ch["epg_xml_path"], []).append(ch)

    total_channels = 0
    total_refs = 0
    for xml_path, channels in sorted(by_file.items()):
        source_el = ET.SubElement(root, "source", type="gen_xmltv", nocheck="1")
        ET.SubElement(source_el, "description").text = "%s - %s" % (
            description, os.path.basename(xml_path))
        ET.SubElement(source_el, "url").text = "file://%s" % xml_path

        channels_el = ET.SubElement(source_el, "channels")
        for ch in channels:
            total_channels += 1
            for m in ch["matches"]:
                chan_el = ET.SubElement(channels_el, "channel", id=ch["channel_id"])
                chan_el.text = m["ref"]
                total_refs += 1

    indent_xml(root)
    xml_body = ET.tostring(root, encoding="unicode")
    xml_text = '<?xml version="1.0" encoding="UTF-8"?>\n' + xml_body
    return xml_text, total_channels, total_refs


def save_sourcexml(matched_channels, output_path=OUTPUT_PATH):
    xml_text, total_channels, total_refs = build_sourcexml(matched_channels)
    atomic_write(output_path, xml_text)
    log.info("Wrote %s: %d channel(s) mapped to %d service reference(s) total",
              output_path, total_channels, total_refs)
    return output_path, total_channels, total_refs
