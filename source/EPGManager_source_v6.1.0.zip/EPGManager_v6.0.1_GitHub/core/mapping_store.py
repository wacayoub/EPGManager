# -*- coding: utf-8 -*-
"""Persistent channel mapping overrides for EPG Manager standalone mode.

The store is intentionally simple JSON so mappings survive plugin upgrades and
can be inspected/recovered without a database.  Keys are XMLTV channel ids and
values are Enigma2 service references.
"""
import json
import os
import time
import shutil

from .logger import get_logger

log = get_logger(__name__)
DEFAULT_PATH = "/etc/enigma2/epgmanager_mappings.json"


class MappingStore(object):
    def __init__(self, path=DEFAULT_PATH):
        self.path = path
        self._data = self._load()

    def _load(self):
        if not os.path.exists(self.path):
            return {"version": 2, "mappings": {}, "history": []}
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if not isinstance(data, dict):
                raise ValueError("mapping file root is not an object")
            data.setdefault("version", 1)
            data.setdefault("mappings", {})
            data.setdefault("history", [])
            return data
        except Exception as exc:
            log.warning("Could not load channel mapping store %s: %s", self.path, exc)
            return {"version": 2, "mappings": {}, "history": []}

    def _save(self):
        directory = os.path.dirname(self.path)
        if directory and not os.path.isdir(directory):
            os.makedirs(directory, exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self._data, fh, separators=(",", ":"), ensure_ascii=False)
        os.replace(tmp, self.path)

    @staticmethod
    def _key(source_id, channel_id):
        return "%s::%s" % (str(source_id or "").lower(), str(channel_id or "").lower())

    def get(self, source_id, channel_id):
        return self._data.get("mappings", {}).get(self._key(source_id, channel_id))

    def set(self, source_id, channel_id, refs, mode="manual", display_name=None):
        if isinstance(refs, str):
            refs = [refs]
        clean = []
        seen = set()
        for ref in refs or []:
            ref = str(ref).strip()
            if ref and ref not in seen:
                seen.add(ref)
                clean.append(ref)
        key = self._key(source_id, channel_id)
        previous = self._data.setdefault("mappings", {}).get(key)
        self._data.setdefault("history", []).append({"ts": int(time.time()), "action": "set", "key": key, "previous": previous})
        self._data["history"] = self._data["history"][-100:]
        self._data.setdefault("mappings", {})[key] = {
            "refs": clean,
            "mode": mode,
            "display_name": display_name or "",
        }
        self._save()
        return clean

    def remove(self, source_id, channel_id):
        key = self._key(source_id, channel_id)
        if key in self._data.get("mappings", {}):
            previous = self._data["mappings"].get(key)
            self._data.setdefault("history", []).append({"ts": int(time.time()), "action": "remove", "key": key, "previous": previous})
            self._data["history"] = self._data["history"][-100:]
            del self._data["mappings"][key]
            self._save()
            return True
        return False

    def all(self):
        return dict(self._data.get("mappings", {}))


    def backup(self, destination=None):
        """Create a safe copy of the current mapping file."""
        if not os.path.exists(self.path):
            self._save()
        destination = destination or (self.path + '.bak')
        shutil.copy2(self.path, destination)
        return destination

    def undo_last(self):
        history = self._data.setdefault('history', [])
        if not history:
            return False
        item = history.pop()
        key = item.get('key')
        previous = item.get('previous')
        if previous is None:
            self._data.setdefault('mappings', {}).pop(key, None)
        else:
            self._data.setdefault('mappings', {})[key] = previous
        self._save()
        return True
