# -*- coding: utf-8 -*-
"""Secure-ish online updater for EPG Manager.

The updater is intentionally repository-agnostic.  The receiver only needs a
small HTTPS JSON manifest.  The manifest points to the current IPK and may
include its SHA-256 digest.  Once the manifest URL is configured once, future
updates can be checked/downloaded/installed entirely from the remote control.
"""
from __future__ import absolute_import

import hashlib
import json
import os
import re
import subprocess
import tempfile

try:
    from urllib.parse import urljoin
except ImportError:  # pragma: no cover - Python 2 compatibility is not target, harmless fallback
    from urlparse import urljoin

from .logger import get_logger

log = get_logger(__name__)

UPDATER_SETTINGS = "/etc/enigma2/epgmanager_online_update.json"
DEFAULT_SETTINGS = {
    "manifest_url": "https://raw.githubusercontent.com/wacayoub/EPGManager/main/update.json",
    "channel": "stable",
}


class UpdateError(Exception):
    pass


def _version_parts(value):
    """Return a tuple suitable for comparing Enigma plugin versions.

    Numeric chunks are compared numerically; suffix text is ignored for the
    stable updater path.  Examples: 5.9.0 < 6.0.0 and 6.0.9 < 6.0.10.
    """
    nums = re.findall(r"\d+", str(value or ""))
    return tuple(int(x) for x in nums[:4]) or (0,)


def is_newer_version(remote, local):
    r = _version_parts(remote)
    l = _version_parts(local)
    n = max(len(r), len(l))
    return r + (0,) * (n - len(r)) > l + (0,) * (n - len(l))


def load_updater_settings(path=UPDATER_SETTINGS):
    data = dict(DEFAULT_SETTINGS)
    try:
        if os.path.exists(path):
            with open(path, "r") as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                data.update(loaded)
                # A settings file created by an older build may contain an empty
                # manifest_url.  Fall back to the official GitHub repository so
                # Online Update works without entering the URL manually.
                if not str(data.get("manifest_url") or "").strip():
                    data["manifest_url"] = DEFAULT_SETTINGS["manifest_url"]
    except Exception as exc:
        log.warning("Could not read updater settings %s: %s", path, exc)
    return data


def save_updater_settings(data, path=UPDATER_SETTINGS):
    payload = dict(DEFAULT_SETTINGS)
    payload.update(data or {})
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    tmp = path + ".tmp"
    with open(tmp, "w") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
    os.rename(tmp, path)
    return payload


def normalize_manifest(payload, manifest_url=""):
    if not isinstance(payload, dict):
        raise UpdateError("Update manifest is not a JSON object")
    version = str(payload.get("version") or "").strip()
    url = str(payload.get("url") or payload.get("ipk") or "").strip()
    if not version:
        raise UpdateError("Update manifest has no version")
    if not url:
        raise UpdateError("Update manifest has no IPK URL")
    if manifest_url:
        url = urljoin(manifest_url, url)
    sha256 = str(payload.get("sha256") or "").strip().lower()
    if sha256 and not re.match(r"^[0-9a-f]{64}$", sha256):
        raise UpdateError("Manifest SHA-256 is invalid")
    try:
        size = int(payload.get("size") or 0)
    except Exception:
        size = 0
    return {
        "version": version,
        "build": str(payload.get("build") or ""),
        "url": url,
        "sha256": sha256,
        "size": max(0, size),
        "notes": str(payload.get("notes") or payload.get("changelog") or ""),
        "mandatory": bool(payload.get("mandatory", False)),
    }


class OnlineUpdater(object):
    def __init__(self, local_version, timeout=20):
        self.local_version = str(local_version)
        self.timeout = max(5, int(timeout))
        self.manifest = None

    def _requests(self):
        try:
            import requests
            return requests
        except ImportError:
            raise UpdateError("python3-requests is required for Online Update")

    def check(self, manifest_url):
        manifest_url = str(manifest_url or "").strip()
        if not manifest_url:
            raise UpdateError("Online update server is not configured")
        if not manifest_url.lower().startswith(("https://", "http://")):
            raise UpdateError("Manifest URL must start with https:// or http://")
        requests = self._requests()
        try:
            response = requests.get(
                manifest_url,
                timeout=self.timeout,
                headers={"User-Agent": "EPGManager/%s" % self.local_version},
            )
            response.raise_for_status()
            payload = response.json()
        except Exception as exc:
            raise UpdateError("Cannot check for updates: %s" % exc)
        self.manifest = normalize_manifest(payload, manifest_url)
        self.manifest["newer"] = is_newer_version(self.manifest["version"], self.local_version)
        return dict(self.manifest)

    def download(self, manifest=None, progress=None):
        info = dict(manifest or self.manifest or {})
        if not info.get("url"):
            raise UpdateError("No update package is available")
        requests = self._requests()
        target = "/tmp/epgmanager_%s.ipk" % re.sub(r"[^0-9A-Za-z._-]", "_", info.get("version", "update"))
        tmp = target + ".part"
        digest = hashlib.sha256()
        received = 0
        expected = int(info.get("size") or 0)
        try:
            response = requests.get(
                info["url"], stream=True, timeout=self.timeout,
                headers={"User-Agent": "EPGManager/%s" % self.local_version},
            )
            response.raise_for_status()
            if not expected:
                try:
                    expected = int(response.headers.get("Content-Length") or 0)
                except Exception:
                    expected = 0
            with open(tmp, "wb") as handle:
                for chunk in response.iter_content(chunk_size=64 * 1024):
                    if not chunk:
                        continue
                    handle.write(chunk)
                    digest.update(chunk)
                    received += len(chunk)
                    if progress:
                        progress(received, expected)
            if received < 1024:
                raise UpdateError("Downloaded package is unexpectedly small")
            expected_sha = str(info.get("sha256") or "").lower()
            actual_sha = digest.hexdigest().lower()
            if expected_sha and actual_sha != expected_sha:
                raise UpdateError("SHA-256 verification failed")
            if os.path.exists(target):
                os.unlink(target)
            os.rename(tmp, target)
            return target, actual_sha, received
        except UpdateError:
            try:
                if os.path.exists(tmp):
                    os.unlink(tmp)
            except Exception:
                pass
            raise
        except Exception as exc:
            try:
                if os.path.exists(tmp):
                    os.unlink(tmp)
            except Exception:
                pass
            raise UpdateError("Update download failed: %s" % exc)

    def install(self, ipk_path):
        if not ipk_path or not os.path.exists(ipk_path):
            raise UpdateError("Downloaded IPK file is missing")
        cmd = ["opkg", "install", "--force-reinstall", ipk_path]
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            output = proc.communicate()[0]
            if not isinstance(output, str):
                output = output.decode("utf-8", "replace")
        except Exception as exc:
            raise UpdateError("Could not start opkg: %s" % exc)
        if proc.returncode != 0:
            tail = "\n".join(output.strip().splitlines()[-8:])
            raise UpdateError("opkg failed (code %d)\n%s" % (proc.returncode, tail))
        return output
