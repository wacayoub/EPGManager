# -*- coding: utf-8 -*-
"""
core/scheduler.py

Enigma2-native scheduling using eTimer - explicitly NOT cron, NOT a
standalone `python3 script.py` process, per spec section 4.

Flow (spec section 4/35/36):
    Enigma2 starts -> plugin __init__ registers a session/autostart hook
    -> EPGManager.core.manager.Manager is created -> Scheduler.start()
    -> checks last successful update timestamp
    -> if now - last_update >= interval: trigger an update in a background
       thread immediately
    -> regardless, arms an eTimer for the next check (a short poll interval,
       e.g. every 5 minutes) so it can react to interval/settings changes
       without needing to compute one huge far-future delay up front.

This module is importable outside of Enigma2 (e.g. for unit tests / CLI
debug mode) - if `enigma.eTimer` can't be imported, a minimal drop-in
replacement backed by `threading.Timer` is used instead, so core logic is
identical either way.
"""

import time

from .logger import get_logger

log = get_logger(__name__)

try:
    from enigma import eTimer
    _HAVE_ENIGMA = True
except ImportError:
    _HAVE_ENIGMA = False

    import threading

    class eTimer(object):
        """Minimal eTimer look-alike for non-Enigma2 environments (unit
        tests, CLI debug mode). Mimics the subset of the real eTimer API
        that this plugin uses: callback via .timeout.get().append(fn),
        .start(ms, singleShot), .stop()."""

        class _Signal(object):
            def __init__(self):
                self._callbacks = []

            def get(self):
                return self._callbacks

        def __init__(self):
            self.timeout = self._Signal()
            self._thread = None
            self._stopped = True

        def start(self, ms, singleShot=False):
            self._stopped = False
            interval = ms / 1000.0

            def _run():
                while not self._stopped:
                    time.sleep(interval)
                    if self._stopped:
                        break
                    for cb in list(self.timeout.get()):
                        try:
                            cb()
                        except Exception:
                            log.exception("Timer callback raised")
                    if singleShot:
                        break

            self._thread = threading.Thread(target=_run, daemon=True)
            self._thread.start()

        def stop(self):
            self._stopped = True


POLL_INTERVAL_MS = 5 * 60 * 1000  # check every 5 minutes whether an update is due


class Scheduler(object):
    def __init__(self, config, on_update_due):
        """
        config: core.config.Config instance (provides update_interval_hours,
                last_update timestamp getter/setter).
        on_update_due: callable() invoked (from the eTimer callback, i.e.
                Enigma2's main thread) when an update should start. The
                caller is responsible for immediately handing the real work
                off to a background thread (see core/manager.py) - the
                scheduler itself never does network I/O.
        """
        self.config = config
        self.on_update_due = on_update_due
        self._timer = eTimer()
        self._timer.timeout.get().append(self._tick)
        self._update_in_progress = False

    def start(self):
        mode = self.config.get_schedule_mode()
        if mode == "daily":
            hh, mm = self.config.get_daily_update_time()
            log.info("Scheduler starting (poll every %ds, daily update at %02d:%02d Casablanca time)",
                      POLL_INTERVAL_MS // 1000, hh, mm)
        elif mode == "weekly":
            hh, mm = self.config.get_daily_update_time()
            from .config import WEEKDAY_NAMES
            day_name = WEEKDAY_NAMES[self.config.get_weekly_update_day()]
            log.info("Scheduler starting (poll every %ds, weekly update on %s at %02d:%02d Casablanca time)",
                      POLL_INTERVAL_MS // 1000, day_name, hh, mm)
        elif mode == "monthly":
            hh, mm = self.config.get_daily_update_time()
            log.info("Scheduler starting (poll every %ds, monthly update on day %d at %02d:%02d Casablanca time)",
                      POLL_INTERVAL_MS // 1000, self.config.get_monthly_update_day(), hh, mm)
        else:
            log.info("Scheduler starting (poll every %ds, every %dh since last update)",
                      POLL_INTERVAL_MS // 1000, self.config.get_update_interval_hours())
        # Immediate check on startup (spec section 36: "check last update ->
        # update if required" right after Enigma2/plugin init).
        self._tick(initial=True)
        self._timer.start(POLL_INTERVAL_MS, False)

    def stop(self):
        self._timer.stop()

    def mark_update_started(self):
        self._update_in_progress = True

    def mark_update_finished(self):
        self._update_in_progress = False
        self.config.set_last_update(time.time())

    def is_update_due(self):
        mode = self.config.get_schedule_mode()
        if mode == "daily":
            return self._is_scheduled_slot_due(self._todays_slot)
        if mode == "weekly":
            return self._is_scheduled_slot_due(self._this_weeks_slot)
        if mode == "monthly":
            return self._is_scheduled_slot_due(self._this_months_slot)
        return self._is_interval_update_due()

    def _is_interval_update_due(self):
        last = self.config.get_last_update()
        if last is None:
            return True
        interval_seconds = self.config.get_update_interval_hours() * 3600
        return (time.time() - last) >= interval_seconds

    def _todays_slot(self, now):
        hour, minute = self.config.get_daily_update_time()
        return now.replace(hour=hour, minute=minute, second=0, microsecond=0)

    def _this_weeks_slot(self, now):
        """The most recent occurrence (today or earlier this week) of the
        configured weekday/time - e.g. if today is Wednesday and the
        configured day is Monday, this returns this Monday at HH:MM."""
        from datetime import timedelta
        hour, minute = self.config.get_daily_update_time()
        target_weekday = self.config.get_weekly_update_day()  # 0=Monday
        days_since_target = (now.weekday() - target_weekday) % 7
        slot_date = now - timedelta(days=days_since_target)
        return slot_date.replace(hour=hour, minute=minute, second=0, microsecond=0)

    def _this_months_slot(self, now):
        """The most recent occurrence of the configured day-of-month/time -
        this month if that day has already passed, last month otherwise."""
        hour, minute = self.config.get_daily_update_time()
        target_day = self.config.get_monthly_update_day()  # 1-28, always valid
        slot_this_month = now.replace(day=target_day, hour=hour, minute=minute,
                                        second=0, microsecond=0)
        if now >= slot_this_month:
            return slot_this_month
        # Configured day hasn't happened yet this month - the most recent
        # slot is last month's occurrence.
        prev_month = now.month - 1 or 12
        prev_year = now.year - 1 if now.month == 1 else now.year
        return now.replace(year=prev_year, month=prev_month, day=target_day,
                            hour=hour, minute=minute, second=0, microsecond=0)

    def _is_scheduled_slot_due(self, slot_fn):
        """Shared logic for daily/weekly/monthly: due once the most recent
        scheduled slot has passed AND we haven't already completed an
        update since then - so a box that's off at the scheduled moment
        and boots later still gets that period's update (spec: "run
        automatically", not "run at exactly HH:MM:00 or never")."""
        from .timezone_manager import TimezoneManager
        tzm = TimezoneManager()
        now = tzm.now()
        slot = slot_fn(now)

        if now < slot:
            return False  # the most recent slot is still in the future somehow (shouldn't happen)

        last = self.config.get_last_update()
        if last is None:
            return True
        last_dt = tzm.from_timestamp(last)
        return last_dt < slot

    def _tick(self, initial=False):
        if self._update_in_progress:
            log.debug("Scheduler tick skipped: an update is already running")
            return
        if self.is_update_due():
            log.info("Update is due%s - triggering background update",
                      " (startup check)" if initial else "")
            try:
                self.on_update_due()
            except Exception:
                log.exception("on_update_due callback raised")
        else:
            log.debug("Update not due yet (mode=%s)", self.config.get_schedule_mode())
