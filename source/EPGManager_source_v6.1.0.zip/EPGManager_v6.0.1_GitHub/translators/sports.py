# -*- coding: utf-8 -*-
"""
translators/sports.py

Centralized sports-translation logic (spec section 27/28), extracted from
the original 4.BEIN_SPORTS.py so any current or future sports source
(beIN, Arryadia, a hypothetical future Al Riyadiya/Arryadia+ feed, etc.)
can reuse the same league/program dictionaries instead of maintaining
separate copies. All dictionary content is preserved verbatim from the
original script - nothing invented or removed.
"""

import re

LEAGUE_MAP = {
    "premier league english": "الدوري الإنجليزي الممتاز",
    "premier league": "الدوري الإنجليزي الممتاز",
    "epl": "الدوري الإنجليزي الممتاز",
    "spanish laliga": "الدوري الإسباني",
    "la liga": "الدوري الإسباني",
    "laliga": "الدوري الإسباني",
    "uefa champions league": "دوري أبطال أوروبا",
    "ucl": "دوري أبطال أوروبا",
    "europa league": "الدوري الأوروبي",
    "uel": "الدوري الأوروبي",
    "conference league": "دوري المؤتمر الأوروبي",
    "fa cup": "كأس الاتحاد الإنجليزي",
    "carabao cup": "كأس الرابطة الإنجليزية",
    "efl": "كأس الرابطة الإنجليزية",
    "bundesliga": "الدوري الألماني",
    "serie a": "الدوري الإيطالي",
    "french ligue 1": "الدوري الفرنسي",
    "ligue 1": "الدوري الفرنسي",
    "ligue": "الدوري الفرنسي",
    "nba": "دوري كرة السلة الأمريكي NBA",
    "world cup qualifiers": "تصفيات كأس العالم",
    "fifa world cup": "كأس العالم",
    "world cup": "كأس العالم",
    "wc": "كأس العالم",
    "euro qualifiers": "تصفيات أمم أوروبا",
    "euro": "أمم أوروبا",
    "copa america": "كوبا أمريكا",
    "afcon": "كأس أمم إفريقيا",
    "afc asian cup": "كأس آسيا",
    "copa del rey": "كأس ملك إسبانيا",
    "qatar stars league": "الدوري القطري",
    "afc champions league": "دوري أبطال آسيا",
    "caf champions league": "دوري أبطال إفريقيا",
    "caf confederation cup": "كأس الكونفدرالية الإفريقية",
    "conmebol sudamericana": "كوبا سودامريكانا",
    "copa libertadores": "كوبا ليبرتادوريس",
    "international friendly": "مباراة دولية ودية",
    "football": "كرة القدم",
    "basketball": "كرة السلة",
    "tennis": "تنس",
}

PROGRAM_MAP = {
    "al hassad": "أخبار الرياضة - الحصاد",
    "news bulletin": "نشرة الأخبار",
    "bulletin": "نشرة",
    "the issue of the day": "الشوط الثالث",
    "special interview": "مقابلة خاصة",
    "special report": "تقرير خاص",
    "discover boston": "اكتشف بوسطن",
    "bein experiments": "تجارب beIN",
    "magazine": "مجلة",
    "review": "ملخص",
    "stories from the city": "قصص من المدينة",
    "from the city": "من المدينة",
    "stories": "قصص",
    "preview": "تقديم",
    "exclusive interview": "مقابلة حصرية",
    "amazing facts": "حقائق مذهلة",
    "sports news": "أخبار الرياضة",
    "news": "أخبار",
    "aljawla": "الجولة",
    "al jawla": "الجولة",
    "the summary": "موجز الأخبار",
    "football legends": "أساطير كرة القدم",
    "netbusters": "قناصو الأهداف",
    "highlights": "ملخصات",
    "nine o'clock": "نشرة التاسعة مساءً",
    "six o'clock": "نشرة السادسة",
    "al hassila": "الحصيلة",
    "ligue1 weekly": "ملخص الدوري الفرنسي الأسبوعي",
    "road to the": "الطريق إلى",
    "episode": "حلقة",
    "studio": "استوديو تحليلي",
    "pre-match": "قبل المباراة",
    "post-match": "بعد المباراة",
    "best world cup player": "أفضل لاعب في كأس العالم",
    "fifa world cup qatar": "كأس العالم قطر",
    "story of fifa world cup": "قصة كأس العالم",
    "all the goals of world cup": "جميع أهداف كأس العالم",
    "all the goals of": "جميع أهداف",
    "historical": "مباراة تاريخية",
    "road to maracana": "الطريق إلى ماراكانا",
    "futebol arte": "كرة القدم الفنية",
    "die mannschaft": "المانشافت",
    "arab pride": "فخر العرب",
    "a lasting legacy": "إرث خالد",
    "the champions": "الأبطال",
    "uefa champions league magazine": "مجلة دوري أبطال أوروبا",
    "champions league legends": "أساطير دوري أبطال أوروبا",
    "fifa film": "فيلم الفيفا",
    "pre-2026 fifa world cup": "تحضيرات كأس العالم 2026",
    "triumphant return home": "العودة المظفرة للوطن",
    "match #": "المباراة رقم ",
    "play-offs": "التصفيات",
    "playoffs": "التصفيات",
    "group stage": "دور المجموعات",
    "inside psg, the": "كواليس PSG",
    "inside psg": "كواليس PSG",
    "inside": "كواليس",
}

META_MAP = {
    "Matchday": "الجولة", "MD": "الجولة", "Week": "الأسبوع",
    "Round of 16": "دور الـ 16", "R16": "دور الـ 16",
    "Quarter": "ربع النهائي", "QF": "ربع النهائي",
    "Semi": "نصف النهائي", "SF": "نصف النهائي",
    "Finals": "النهائي", "Final": "النهائي",
    "1st Leg": "الذهاب", "2nd Leg": "الإياب",
    "Group": "المجموعة", "Round": "الجولة",
}


def translate_metadata(meta_text):
    if not meta_text:
        return ""
    for eng, ara in sorted(META_MAP.items(), key=lambda x: len(x[0]), reverse=True):
        meta_text = re.sub(r"\b%s\b" % re.escape(eng), ara, meta_text, flags=re.IGNORECASE)
    return meta_text


def extract_metadata(text):
    """Split raw title text into (cleaned_text, translated_metadata_string).
    Metadata = dates, seasons, matchday/round markers found in the text."""
    extracted_info = []

    date_matches = re.findall(r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b", text)
    for d in date_matches:
        extracted_info.append(d)
        text = text.replace(d, "")

    for p in (r"\b20\d{2}/\d{2,4}\b", r"\b20\d{2}-\d{2,4}\b"):
        match = re.search(p, text)
        if match:
            extracted_info.append(match.group(0))
            text = text.replace(match.group(0), "")

    round_patterns = [
        r"\b(MD|Matchday|Week|Round|round of)\s*\d+\b",
        r"\bR(16|8|4|2|32|64)\b",
        r"\b(Quarter|Semi|Finals?|2nd|1st|Leg|QF|SF)\b",
        r"\bGroup\s+[A-Z]\b",
    ]
    for p in round_patterns:
        matches = re.findall(p, text, re.IGNORECASE)
        if matches:
            text = re.sub(p, "", text, flags=re.IGNORECASE)
            for m in matches:
                extracted_info.append(m[0] if isinstance(m, tuple) else m)

    translated_info = [translate_metadata(info) for info in dict.fromkeys(extracted_info)]
    metadata = " | ".join(translated_info).strip()

    text = re.sub(r"\s*[-:/|]\s*[-:/|]\s*", " - ", text)
    text = re.sub(r"^\s*[-:/|]\s*", "", text)
    text = re.sub(r"\s*[-:/|]\s*$", "", text)
    return text.strip(), metadata


def translate_text(text):
    """Translate league/program terminology within `text` to Arabic."""
    if not text:
        return ""
    text = text.replace("الرياضة العام", "").replace("الأخبار الرياضية", "").strip()
    all_maps = {}
    all_maps.update(PROGRAM_MAP)
    all_maps.update(LEAGUE_MAP)
    for eng, ara in sorted(all_maps.items(), key=lambda x: len(x[0]), reverse=True):
        text = re.sub(r"\b%s\b" % re.escape(eng), ara, text, flags=re.IGNORECASE)
    text = re.sub(r"English\s+الدوري الإنجليزي", "الدوري الإنجليزي", text, flags=re.IGNORECASE)
    text = re.sub(r"French\s+الدوري الفرنسي", "الدوري الفرنسي", text, flags=re.IGNORECASE)
    text = re.sub(r"Spanish\s+الدوري الإسباني", "الدوري الإسباني", text, flags=re.IGNORECASE)
    return text.strip()


def get_league_arabic(text):
    if not text:
        return ""
    text_lower = text.lower()
    for english_name, arabic_name in sorted(LEAGUE_MAP.items(), key=lambda x: len(x[0]), reverse=True):
        if english_name in text_lower:
            return arabic_name
    return ""
