# -*- coding: utf-8 -*-
"""
translators/darija.py

The Darija/French translation engine, ported from the original 2M/Chada
script's `Translator` class. ALL dictionaries (french_shows_whitelist,
tv_prefixes, official_titles, darija_filter) are preserved verbatim. The
three JSON side-files it maintained (translation_cache.json,
custom_dictionary.json, unknown_shows.json) are preserved with the exact
same filenames and semantics, now backed by core.cache.JSONCache instead of
three separate hand-rolled load/save functions.

HONEST LIMITATION on Darija translation quality (2026-08-09)
--------------------------------------------------------------
For anything NOT already covered by `official_titles` (the curated,
exact, correct dictionary of known recurring show names), the pipeline is:
    French text -> Google Translate's free endpoint (French -> STANDARD
    Arabic/Fusha, since Google Translate has no Darija target) -> a ~100-
    word find/replace pass (`darija_filter`, expanded 2026-08-09) that
    swaps the most common Fusha words for their Darija equivalent.

This is a genuine, hard ceiling on quality: Google's output is fluent
Fusha, and no small word-substitution table can turn fluent Fusha into
fluent Darija - Darija differs from Fusha in grammar and word order, not
just vocabulary, which a dictionary swap cannot fix. The result for
anything outside `official_titles` will read as "Fusha with some Darija
words mixed in," not native Darija. There is no way to close this gap
with more dictionary entries alone.

What actually produces CORRECT Darija: the `official_titles` dictionary.
Every entry there is a human-curated, exact translation, not a machine
approximation - which is why the most effective way to improve quality is
to grow `official_titles` (or the operator-editable
custom_dictionary.json, which always overrides it) with more of the
SPECIFIC recurring show names/phrases that come up on 2M/Chada, rather
than expecting the generic fallback path to ever produce native-quality
output. If you have concrete examples of wrong output, add the correct
Darija translation directly to custom_dictionary.json (format:
{"normalized french text": "الترجمة الصحيحة"}) - that's a real, permanent
fix for that specific title; expanding darija_filter only ever nudges
individual words in already-Fusha sentences, and can't fix word order.
"""

import re

from ..core.cache import JSONCache
from ..core.logger import get_logger
from .arabic import normalize_text, contains_latin_letters

log = get_logger(__name__)

EPG_DIR = "/etc/epgimport/jedi_epg"
CACHE_PATH = "%s/translation_cache.json" % EPG_DIR
CUSTOM_DICT_PATH = "%s/custom_dictionary.json" % EPG_DIR
UNKNOWN_SHOWS_PATH = "%s/unknown_shows.json" % EPG_DIR

GOOGLE_TRANSLATE_URL = "https://translate.googleapis.com/translate_a/single"


class DarijaTranslator(object):
    def __init__(self, downloader=None, enable_network=True):
        # IMPORTANT: the original script's Translator._translate_google_free()
        # made a SINGLE attempt (`session.get(url, timeout=5)`, no retry loop)
        # and just fell back to the original text on any failure - that's
        # what makes it fast even when Google's free endpoint is flaky.
        # A previous revision of this plugin passed in the source's shared,
        # retrying Downloader (3 attempts + exponential backoff) here, which
        # silently turned every failed translation into a ~7-10s stall
        # instead of an instant fallback. With ~100+ translation calls per
        # run, that alone plausibly accounts for multi-minute slowdowns.
        #
        # This translator now builds its OWN fast, single-attempt downloader
        # by default (ignoring any shared, slower downloader a caller might
        # be tempted to pass in) unless a `downloader` is explicitly given
        # (e.g. a test double) or `enable_network=False` is passed (offline
        # mode - translation always falls back to the original text
        # instantly, used by the test suite for determinism).
        if downloader is not None:
            self.downloader = downloader
        elif enable_network:
            from ..core.downloader import Downloader
            self.downloader = Downloader(retries=1, timeout=5)
        else:
            self.downloader = None

        self.cache = JSONCache(CACHE_PATH)
        self.custom_dict_cache = JSONCache(CUSTOM_DICT_PATH)
        self.unknown_shows_cache = JSONCache(UNKNOWN_SHOWS_PATH)

        self.french_shows_whitelist = [
            "auto moto", "grand angle", "rallye aicha", "pop up",
            "replay", "info soir", "eco news", "eclairages", "jt francais",
            "le journal", "meteo", "jt", "journal francais", "sport",
            "documentaire francais", "film francais", "magazine",
            "planete foot", "esme & roy", "mondial stories", "jamel comedy club",
        ]

        self.tv_prefixes = {
            "serie marocaine": "مسلسل مغربي",
            "serie turque": "مسلسل تركي",
            "serie": "مسلسل",
            "film tv": "فيلم تلفزي",
            "film marocain": "فيلم مغربي",
            "film": "فيلم",
            "documentaire": "وثائقي",
            "magazine": "برنامج",
            "best of": "أفضل ما في",
            "rediffusion": "إعادة",
        }

        self.official_titles = {
            "le journal": "الأخبار", "al akhbar": "الأخبار", "journal amazigh": "الأخبار بالأمازيغية",
            "jt arabe": "الأخبار بالعربية", "al massaiya": "المسائية", "al dahira": "الظهيرة",
            "meteo": "حالة الطقس", "clips": "كليبات",
            "sabahiyat": "2M صباحيات", "sabahiyat 2m": "2M صباحيات", "rachid show": "رشيد شو",
            "kif el hal": "كيف الحال", "kif al hal": "كيف الحال",
            "moudawala": "مداولة", "stand up": "ستاند آب", "master chef": "ماستر شيف",
            "lmatch": "الماتش", "ma3a ramdani": "مع الرمضاني",
            "mubasharatan maakum": "مباشرة معكم", "massar": "مسار", "naghma watay": "نغمة وأتاي",
            "chhiwat bladi": "شهيوات بلادي", "maqtou3 men chajra": "مقطوع من شجرة",
            "chhiwa ma3a choumicha": "شهيوات مع شميشة", "3ailti": "عائلتي",
            "sahatna jmi3": "صحتنا جميع", "mawazine": "موازين", "asrar al mondial": "أسرار المونديال",
            "al barlamane wa annass": "البرلمان والناس", "zour bladek": "زور بلادك",
            "riad azzaytoune": "رياض الزيتون", "lmktoub": "المكتوب", "bghit hyatek": "بغيت حياتك",
            "kaina dorouf": "كاين ظروف", "jouj wjouh": "جوج وجوه", "dar nsa": "دار النسا",
            "jib darkom": "جيب داركم", "samhini": "سامحيني", "al waed": "الوعد",
            "3ayne libra": "عين ليبرا", "3ayn libra": "عين ليبرا",
            "alhane 3chaqnaha": "ألحان عشقناها", "alhane 3cha9naha": "ألحان عشقناها",
            "alhan 3chaqnaha": "ألحان عشقناها",
        }
        # Custom, operator-editable overrides always win.
        self.official_titles.update(self.custom_dict_cache.as_dict())

        self.darija_filter = {
            "ماذا": "شنو", "كيف": "كيفاش", "لماذا": "علاش", "متى": "وقتاش",
            "أين": "فين", "الآن": "دابا", "كثيرا": "بزاف", "قليلا": "شوية",
            "جيد": "مزيان", "أريد": "بغيت", "يريد": "بغى", "تريد": "بغات",
            "يذهب": "كيمشي", "سيارة": "طوموبيل", "منزل": "دار", "المنزل": "الدار",
            "عائلة": "عائلة", "العائلة": "العائلة", "أطفال": "وليدات", "الأطفال": "الوليدات",
            "امرأة": "مرا", "المرأة": "المرا", "رجل": "راجل", "الرجل": "الراجل",
            "حسنا": "واخا", "اليوم": "اليوم", "غدا": "غدا", "البارحة": "البارح",
            "نعم": "أه", "هل": "واش", "ليس": "ماشي", "لست": "ماشي", "هذا": "هادا",
            "هذه": "هادي", "هنا": "هنا", "هناك": "تِما", "جدا": "بزاف",
            "لدي": "عندي", "لديه": "عندو", "لديها": "عندها", "نقود": "فلوس",
            "المال": "الفلوس", "عمل": "خدمة", "العمل": "الخدمة", "يعمل": "كيخدام",
            "صديق": "صاحب", "صديقي": "صاحبي", "أخي": "خويا", "أختي": "ختي",
            "أمي": "مي", "أبي": "با", "طعام": "ماكلة", "الطعام": "الماكلة",
            "يأكل": "كياكل", "يشرب": "كيشرب", "ينام": "كينعس", "يستيقظ": "كيفيق",
            "يتكلم": "كيهضر", "يتحدث": "كيهضر", "ينظر": "كيشوف", "يرى": "كيشوف",
            "يفعل": "كيدير", "الخاص بي": "ديالي", "الخاص بك": "ديالك", "الذي": "اللي",
            "التي": "اللي", "الذين": "اللي", "يجب": "خاص", "كبير": "كبير", "صغير": "صغير",
            "جميل": "زوين", "سيء": "خايب",
            # -- expanded 2026-08-09: additional common TV-listing vocabulary
            # (this is a straightforward vocabulary EXPANSION, not a fix to
            # the underlying approach - see the module docstring below for
            # why automated Darija translation has a hard ceiling this
            # dictionary alone cannot fully close).
            "يشاهد": "كيتفرج", "مشاهدة": "التفرج", "يضحك": "كيضحك", "مضحك": "كيضحك",
            "غاضب": "زعفان", "سعيد": "فرحان", "حزين": "حزين", "متأخر": "فايت",
            "مبكرا": "بكري", "أمس": "البارح", "أسبوع": "سيمانة", "طفل": "درّي",
            "طفلة": "دريّة", "زوج": "الراجل ديالها", "زوجة": "المرا ديالو",
            "أبدا": "والو", "لا شيء": "والو", "شيء": "حاجة", "كثير": "بزاف",
            "قليل": "شوية", "فقط": "غير", "أيضا": "حتى", "لكن": "ولكين",
            "لأن": "حيت", "إذا": "إلا", "من فضلك": "عافاك", "عفوا": "سمح ليا",
            "حقيقي": "بصح", "بالتأكيد": "أكيد", "ربما": "يمكن", "مستحيل": "محال",
            "سريع": "بزربة", "ببطء": "بشوية", "قوي": "قوي", "ضعيف": "ضعيف",
        }

    def flush(self):
        """Persist any pending cache/unknown-shows writes to disk. Call once
        per source run, not per-title (keeps I/O bounded)."""
        self.cache.save()
        self.unknown_shows_cache.save()

    def is_whitelisted_french(self, text):
        clean_base = normalize_text(text)
        return any(show in clean_base for show in self.french_shows_whitelist)

    def extract_metadata(self, text):
        saison, episode = "", ""
        s_match = re.search(r"(?i)saison\s*(\d+)", text)
        if s_match:
            saison = s_match.group(1)
            text = text[:s_match.start()] + text[s_match.end():]

        e_match = re.search(r"(?i)(?:épisode|episode|ep|ép)\s*(\d+)", text)
        if e_match:
            episode = e_match.group(1)
            text = text[:e_match.start()] + text[e_match.end():]

        text = re.sub(r"(?i)\s*-\s*rediffusion.*", "", text)
        text = re.sub(r"(?i)\s*rediffusion.*", "", text)
        text = re.sub(r"(?i)\s*-\s*rediff.*", "", text)
        text = re.sub(r"\s*[:\-]\s*$", "", text.strip())

        suffix = ""
        if saison:
            suffix += " الموسم %s" % saison
        if episode:
            suffix += " الحلقة %s" % episode
        return text.strip(), suffix

    def apply_darija_filter(self, arabic_text):
        words = arabic_text.split()
        for i, word in enumerate(words):
            clean_word = re.sub(r"[^\w\s]", "", word)
            if clean_word in self.darija_filter:
                words[i] = words[i].replace(clean_word, self.darija_filter[clean_word])
        return " ".join(words)

    def translate(self, text, is_after_massaiya=False, is_after_infosoir=False,
                  is_desc=False, keep_french=False):
        if not text:
            return ""
        if keep_french:
            return text.strip()

        if is_desc:
            clean_desc = text.strip()
            if not contains_latin_letters(clean_desc):
                return clean_desc
            return self._translate_google_free(clean_desc, "")

        if re.fullmatch(r"\d{1,2}[:h]\d{2}", text.strip().lower()):
            return text.strip()

        base_text, meta_suffix = self.extract_metadata(text)
        if not base_text:
            return meta_suffix.strip()

        norm_base = normalize_text(base_text)

        if "meteo" in norm_base:
            return (("Météo%s" % meta_suffix).strip() if is_after_infosoir
                    else ("حالة الطقس%s" % meta_suffix).strip())

        prefix_ar = ""
        main_title = base_text
        keep_title_french = False

        foreign_indicators = ["film tv", "documentaire", "magazine", "film", "serie"]
        local_indicators = ["marocain", "marocaine", "turque", "arabe", "turc"]

        for fr_pref, ar_pref in sorted(self.tv_prefixes.items(), key=lambda x: len(x[0]), reverse=True):
            if norm_base.startswith(fr_pref):
                main_title_raw = re.sub(r"(?i)^%s\s*[:\-]?\s*" % re.escape(fr_pref), "", base_text)
                main_title = main_title_raw.strip()
                prefix_ar = ar_pref + " : "
                norm_base = normalize_text(main_title)

                if fr_pref in foreign_indicators and not any(loc in fr_pref for loc in local_indicators):
                    if not any(loc in norm_base for loc in local_indicators):
                        keep_title_french = True
                break

        if not main_title:
            return ("%s%s" % (prefix_ar.replace(" : ", ""), meta_suffix)).strip()

        if norm_base in self.official_titles:
            return ("%s%s%s" % (prefix_ar, self.official_titles[norm_base], meta_suffix)).strip()

        for fr_key, ar_val in sorted(self.official_titles.items(), key=lambda x: len(x[0]), reverse=True):
            if fr_key in norm_base:
                return ("%s%s%s" % (prefix_ar, ar_val, meta_suffix)).strip()

        if keep_title_french:
            return ("%s%s%s" % (prefix_ar, main_title, meta_suffix)).strip()

        translated_title = self._translate_google_free(main_title, "")
        return ("%s%s%s" % (prefix_ar, translated_title, meta_suffix)).strip()

    def _translate_google_free(self, base_text, meta_suffix):
        clean_base = base_text.lower().strip()

        cached = self.cache.get(clean_base)
        if cached is not None:
            return ("%s%s" % (cached, meta_suffix)).strip()

        if self.downloader is None:
            # No network access configured for this translator instance -
            # return the original text rather than crash.
            return ("%s%s" % (base_text, meta_suffix)).strip()

        try:
            resp = self.downloader.get_or_none(
                GOOGLE_TRANSLATE_URL,
                params={"client": "gtx", "sl": "fr", "tl": "ar", "dt": "t", "q": base_text},
            )
            if resp is not None:
                json_data = resp.json()
                if json_data and isinstance(json_data, list):
                    res_fusha = "".join(sentence[0] for sentence in json_data[0] if sentence[0])

                    if res_fusha.strip().lower() == clean_base:
                        if not self.is_whitelisted_french(clean_base):
                            self.unknown_shows_cache.set(clean_base, "")
                        return ("%s%s" % (base_text, meta_suffix)).strip()

                    res_darija = self.apply_darija_filter(res_fusha)
                    self.cache.set(clean_base, res_darija)
                    return ("%s%s" % (res_darija, meta_suffix)).strip()
        except Exception as e:
            log.debug("Google Free Translate failed for %r: %s", base_text, e)

        return ("%s%s" % (base_text, meta_suffix)).strip()
