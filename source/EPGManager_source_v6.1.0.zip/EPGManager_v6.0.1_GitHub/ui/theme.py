# -*- coding: utf-8 -*-
"""OpenATV / Metrix inspired visual system for EPG Manager.

Important: Enigma2 uses the high ARGB byte as *transparency*
(00 = opaque, FF = fully transparent).  The v2.6 theme deliberately uses
a denser OpenATV/Matrix glass treatment.  Main cards are now about
90% opaque: the live TV remains only faintly visible through the panels while
text and table geometry stay crisp on bright channels.
"""

# No global veil: live TV keeps its original colours outside the plugin cards.
BG = "#FF000000"
BG_HEX_INT = 0xFF000000

# Dense glass surfaces. Enigma2 alpha is inverse: 00 = opaque, FF = transparent.
# 0x18 is only ~9% transparent, close to the generated target/reference.
PANEL = "#08070C12"
PANEL_HEX_INT = 0x08070C12
PANEL_ALT = "#080A1119"
PANEL_ALT_HEX_INT = 0x080A1119
PANEL_BLUE = "#08091B3A"
PANEL_BLUE_HEX_INT = 0x08091B3A

# Rows are even denser so each source reads as a solid TV-menu row.
PANEL_ROW = "#060F1822"
PANEL_ROW_HEX_INT = 0x060F1822
PANEL_ROW_ALT = "#06111B25"
PANEL_ROW_ALT_HEX_INT = 0x06111B25
PANEL_SELECTED = "#0013324A"
PANEL_SELECTED_HEX_INT = 0x0013324A
PANEL_DISABLED = "#2410161D"
PANEL_DISABLED_HEX_INT = 0x2410161D

# Dedicated footer/navigation surface and full-width action footer.
NAV_PANEL = "#04070C12"
NAV_PANEL_HEX_INT = 0x04070C12
FOOTER_PANEL = "#02070C12"
FOOTER_PANEL_HEX_INT = 0x02070C12

TEXT = "#FFFFFF"
TEXT_INT = 0xFFFFFF
MUTED_TEXT = "#E6EBF0"
MUTED_TEXT_INT = 0xE6EBF0
DIM_TEXT = "#C8D0D8"
DIM_TEXT_INT = 0xC8D0D8
WHITE = "#FFFFFF"
WHITE_INT = 0xFFFFFF
RULE = "#EEF3F7"
RULE_INT = 0xEEF3F7

RULE_SOFT = "#1F3A4A"
RULE_SOFT_INT = 0x1F3A4A

ACCENT_PRIMARY = "#55BEFF"
ACCENT_PRIMARY_INT = 0x55BEFF
ACCENT_SECONDARY = "#7BD8FF"
ACCENT_SECONDARY_INT = 0x7BD8FF
STATUS_GREEN = "#35F09A"
STATUS_GREEN_INT = 0x35F09A
STATUS_YELLOW = "#FFD75A"
STATUS_YELLOW_INT = 0xFFD75A
STATUS_ORANGE = "#FFB15E"
STATUS_ORANGE_INT = 0xFFB15E
STATUS_RED = "#FF7070"
STATUS_RED_INT = 0xFF7070
# IDLE/default text is deliberately near-white now; grey was too faint on TV.
STATUS_GREY = "#E1E6EB"
STATUS_GREY_INT = 0xE1E6EB

BTN_RED = "#D63E3E"
BTN_GREEN = "#31B46F"
BTN_YELLOW = "#D0AA27"
BTN_BLUE = "#3181C5"
BTN_TEXT = "#FFFFFF"


def key_bar_skin(name, x, y, width, height, color, font_size=28):
    """OpenATV-style colour key: slim rail + translucent dark strip."""
    rail_w = 9
    gap = 21
    return (
        '<widget name="%s_bar" position="%d,%d" size="%d,%d" backgroundColor="%s" />\n'
        '        <widget name="%s" position="%d,%d" size="%d,%d" font="Regular;%d" '
        'foregroundColor="%s" backgroundColor="%s" transparent="0" valign="center" />\n'
    ) % (name, x, y, rail_w, height, color,
         name, x + rail_w + gap, y, max(1, width - rail_w - gap), height,
         font_size, TEXT, NAV_PANEL)
