# EPG Manager v1.2.0

Matrix/OpenATV-inspired Full-HD UI, bundled plugin logo, coordinated selected-source updates, and Enigma2-native scheduling.

# EPG Manager

A cron-free, native Enigma2/Vu+ plugin that automatically downloads,
parses, translates, and generates XMLTV EPG files for six Moroccan/regional
channel groups, and feeds them straight into Jedi EPG Importer.

Rebuilt from six standalone scripts (`1.MEDI1TV.py`, `2.2M_CHADA.py`,
`3.SNRT.py`, `4.BEIN_SPORTS.py`, `5.ALMAJD.py`, `7.ARRYADIA.py`) that
previously required a crontab and manual `python3 script.py` execution.
**All scraping/parsing/translation logic from those scripts is preserved**;
see "What changed vs the original scripts" below for the specific bug fixes
and architecture changes.

---

---

## Background transparency reverted (2026-08-09, latest) - real regression, not a style choice

Your screenshots showed the actual result of the previous round's
"semi-transparent panels" experiment, and it was bad: on your receiver it
rendered as **nearly fully transparent**, not a subtle blend - live video
showed through almost the entire screen, text sat directly on top of a
football match with no readable panel behind it, and it visually collided
with the box's own EPG/channel ticker. **Reverted to fully opaque
backgrounds** (`ui/theme.py`: `BG`/`PANEL_ALT` back to plain 6-digit hex,
no alpha channel) - matching the reference screenshot's actual main panel,
which is itself essentially fully opaque (the transparency in that
reference is only in its separate, smaller right-hand description pane,
which this plugin doesn't have). Also caught and fixed a related miss
from the same round: `key_bar_skin()`'s default font size was never
scaled up to match the rest of the 1920x1080 layout, so every screen's
Cancel/Save/etc. key-bar text was rendering undersized relative to
everything else - fixed alongside the background revert.

## Settings LEFT/RIGHT bug + resolution + Medi1TV/2M fixes (2026-08-09)

- **Settings LEFT/RIGHT actually works now.** Root cause confirmed against
  real Enigma2 source: the screen built a bare `ConfigList` widget and its
  own ActionMap only bound OK/Cancel/color-keys - LEFT/RIGHT were never
  wired to the list at all. Fixed by switching to Enigma2's own
  `Components.ConfigList.ConfigListScreen` mixin (the base class virtually
  every real Setup screen uses), which registers the correct key bindings
  itself instead of me hand-wiring them again. A source-level regression
  test guards against this recurring.
- **Full HD, 1920x1080**, matching the reference OpenATV screenshot's
  scale - every screen, every column position, every font size scaled up
  1.5x from the previous 1280x720 layout.
- **Semi-transparent panels** (ARGB colors) instead of fully opaque, to
  echo the reference screenshot's look of live video faintly visible
  behind the UI. Support for this varies by Enigma2 image/skin engine -
  documented in `ui/theme.py` with a one-line way to force fully opaque
  if a particular box doesn't render it correctly.
- **Medi1TV parser rewritten against the REAL live markup.** Fetched and
  read the actual page: the "primary" CSS-class selectors it had been
  using (`card-line`, `program-item`, etc.) don't exist anywhere on the
  real site - every single day was silently falling through to a weak
  last-resort branch that only ever captured time+title, never a
  description. Rewritten from scratch against the real structure (a flat,
  ordered sequence of `<a>` links per programme), with 8 new tests against
  markup shaped like the real page. Also documented an honest, separate
  limitation: TV sites commonly don't publish schedules far in advance, so
  a thin day count for far-future days may be genuinely missing source
  data, not a parser bug.
- **2M/Chada Darija translation - vocabulary expanded, limitation
  documented honestly.** Added ~30 more common words to the Darija
  word-substitution filter. Also added a clear explanation of why this
  approach has a hard quality ceiling: anything not in the curated
  `official_titles` dictionary goes through Google Translate (French ->
  Standard Arabic/Fusha, since Google has no Darija target) plus a
  word-substitution pass, which can swap individual words but can't fix
  Darija's different grammar/word order - no dictionary size can close
  that gap. The real fix path is adding specific correct translations to
  `custom_dictionary.json` (operator-editable, always wins) - happy to
  add more if given concrete wrong-output examples.

## OpenATV Matrix-style theme + more fixes (2026-08-09)

- **Key bars, not button blocks.** Reworked every screen's bottom action
  row to match OpenATV's own setup-screen look (see the "EPG Import
  Configuration" reference screenshot): a thin colored vertical bar next
  to plain text, instead of big solid-colored rectangles. New
  `ui/theme.py:key_bar_skin()` helper generates this consistently across
  all five screens.
- **"Last Update" now actually updates for manual runs.** Root cause: the
  per-source update path (`_run_one_wrapper()` - used by the dashboard's
  checkbox "Update Selected", the "9" quick-update shortcut, and the
  Sources screen) never called `set_last_update()` at all - only a full
  scheduler cycle did. Since manual single-source updates are the primary
  way most people use the dashboard, "Last Update" could show "Never" or
  a stale time indefinitely even right after a successful manual update.
  Fixed, with a regression test.
- **Log capped at last 80 lines** (was briefly showing the entire file,
  overcorrecting from the original 40-line limit - now a proper middle
  ground with the same scrollable viewer).
- **Weekly and monthly schedule modes** added alongside daily/interval -
  pick a day of the week or a day of the month (1-28, capped to sidestep
  "day 31 doesn't exist in February" entirely) plus a time of day.
- **Status color legend removed** from the dashboard per request.
- **Selection toggle rewritten to be index-based** rather than trusting
  the list widget's row-data lookup, with debug logging on every toggle,
  plus a bold full-height colored flag-bar per row (not just the small
  `[X]`/`[ ]` marker) so a checked row is unmistakable at a glance.

## UI/UX and configurability pass (2026-08-09)

- **Configurable EPG export directory** (Settings -> "EPG export
  directory"): the six generated XMLTV files no longer have to go to
  `/etc/epgimport/jedi_epg` - point EPG Manager at any writable folder
  (an HDD/USB mount, a different EPG-Importer directory, etc.). All six
  sources, the Channel Mapping scanner, and the sourcexml exporter all
  read this setting; nothing is hardcoded anymore.
- **Native time picker for the daily update time**: switched from typing
  "06:00" character-by-character to a real `ConfigClock` widget (the same
  one Enigma2's own timer/wakeup screens use) - LEFT/RIGHT adjusts
  hour/minute directly.
- **Full-screen** dashboard, Settings, Sources, Logs, and Channel Mapping
  screens (1280x720 at the time - later bumped to 1920x1080, see above) -
  no longer small centered dialogs floating over live video.
- **Selection checkboxes actually visible now.** The previous ☑/☐ Unicode
  checkbox glyphs (U+2610/U+2611) may not exist at all in some Enigma2
  skin fonts, which could make a successful selection look like nothing
  happened. Replaced with plain ASCII `[X]`/`[ ]`, plus a persistent
  tinted background on any checked row (independent of cursor position)
  so a selection is unmistakable at a glance.
- **Update just one source, instantly**: press `9` on the highlighted row
  to update only that source, without touching the batch-selection
  checkboxes at all.
- **Full log viewer**: the Logs/About screen now shows the entire log
  file in a proper scrollable widget (`ScrollLabel`, with UP/DOWN/0/9 to
  navigate), not a fixed last-40-lines snippet.
- **Bigger fonts throughout Settings**, plus a background "card" panel
  behind the Status/Last Update/Next Update block on the dashboard, and
  color-coded status text (green=READY, yellow=UPDATING,
  orange=CANCELLING).

## Critical fix (2026-08-09): runaway auto-updates that got SNRT to block you

**Root cause found and fixed.** `Scheduler.mark_update_finished()` - the
method responsible for recording "an update cycle just completed" - was
written but **never actually called anywhere** in the real code path. That
meant `config.get_last_update()` stayed `None` forever, so every 5-minute
scheduler poll saw "no update has ever completed" and re-triggered a brand
new full update cycle - forever, in a loop, regardless of the schedule
setting. This is almost certainly what got SNRT to IP-ban the box: it was
being hit with repeated full scrapes every few minutes, indefinitely.

Fixed at the source (`core/manager.py:_run_all()` now persists
`last_update` unconditionally - success or failure - the moment a cycle
finishes), plus two more layers of protection added on top:

- **A 20-minute per-source cooldown** (`core/manager.py:
  MIN_SOURCE_COOLDOWN_SECONDS`): a source can't be re-attempted within 20
  minutes of its last attempt, regardless of who triggers it (scheduler or
  a manual click), so even repeated manual clicks on the same source can't
  hammer a site. Shows as an orange "COOLDOWN" status with an explanation.
- **The dashboard's checkbox selection now actually sticks.** The list
  widget was being fully rebuilt every second by the status-poll timer,
  which silently reset Enigma2's list cursor back to row 0 each time -
  so pressing OK often toggled a different row than the one you'd
  navigated to, or the visible checkmark appeared to "not take". Fixed by
  preserving/restoring the cursor position across rebuilds, and by only
  rebuilding the list at all when something actually changed.
- **The "1: Open EPG-Importer" button was still risking a real import.**
  Checked the actual public source of several EPG-Importer forks: on the
  oe-alliance `XMLTV-Import` fork, the Extensions-menu entry is literally
  named "EPG-Importer Now" with `fnc=start_import` - it runs the import
  immediately, full stop, no way around it from outside. Its Plugin-menu
  entry ("EPG-Importer", `fnc=main`) just opens the screen, with no side
  effects. The launcher now prefers Plugin-menu entries over
  Extensions-menu ones (consistently the safe choice across every fork
  checked), plus a wider word-boundary check for "action" words like a
  standalone "now".
- **Fewer, more purposeful colors.** Reworked into a calmer theme
  (`ui/theme.py`): a single violet/cyan accent pair for branding and
  navigation, with red/green/yellow/blue backgrounds reserved *only* for
  the four physical remote color-keys, and green/yellow/orange/red/grey
  reserved *only* for source status - so a color never means two
  different things depending on where you look.
- A `Label` import that was missing from `ui/settings.py` (would have
  crashed that screen with a `NameError` the moment it tried to show the
  hint text) was also caught and fixed while working through this.

## What changed since the first release

- **Egypt +1 removed** entirely (was a disabled stub since that script was
  never supplied) - no longer registered, no longer in Settings, no longer
  in the uninstaller's file list.
- **Daily scheduling**: default mode is now "once a day at a fixed time"
  (06:00 Casablanca time by default, configurable in Settings), instead of
  "every N hours since the last success". A box that's off overnight and
  boots late still catches that day's update rather than skipping it. The
  old interval-based mode is still available (`Schedule mode` ->
  `interval` in Settings).
- **Cancel button**: while an update is running, the dashboard's RED
  button changes from "Update Selected" to "Cancel Update". Cancellation
  is best-effort - it stops the run at the next request boundary
  (typically within a few seconds), not instantly mid-download, since an
  in-flight HTTP request can't be safely aborted from another thread.
- **Automatic channel mapping** (dashboard key `3`): reads the `<channel>`
  entries out of your actually-generated XMLTV files, scans every
  `/etc/enigma2/userbouquet.*.tv` file on the receiver, and fuzzy-matches
  EPG channel names against real services by name - across every
  satellite/bouquet you have (e.g. a channel named "2M" gets matched
  against every "2M"-named service found on Nilesat, Astra, Hotbird, Badr,
  etc., independently). One button writes an EPG-Importer-style
  `sources.xml` for everything matched.
- **Bigger dashboard** (1200x700, up from 960x620), with a color legend
  row so the green/yellow/orange/red/grey status colors are
  self-explanatory, and a live "X of Y sources selected" counter.
- **beIN Sports and 2M/Chada bug fixes** - see "Bugs found and fixed in
  this plugin" below; both were introduced during the original port, not
  present in your working standalone scripts.
- The EPG-Importer quick-launch button now avoids plugin entries whose
  name/description suggests they trigger an immediate import/run,
  preferring one that just opens the plugin's normal screen.

---

## Project overview

```
EPGManager/
├── __init__.py, plugin.py, version.py     # Enigma2 plugin entrypoint
├── core/          # downloader, retry, timezone, xmltv, cache, logger,
│                  # scheduler (eTimer, no cron, daily/interval modes),
│                  # dependency manager, validation, config, manager
│                  # (orchestrator + cancellation), channel_mapper,
│                  # epgimport_export, plugin_launcher
├── sources/       # one module per EPG source (medi1tv, chada_2m, snrt,
│                  # bein_sports, almajd, arryadia)
├── translators/   # arabic.py, darija.py, sports.py - shared translation
│                  # dictionaries and engines
├── config/        # defaults.json
├── data/          # starter copies of translation_cache.json,
│                  # custom_dictionary.json, unknown_shows.json
├── ui/            # Enigma2 GUI screens (main dashboard, sources,
│                  # settings, logs, channel mapping)
├── installer/     # install.sh, uninstall.sh, build_ipk.sh, ipk/CONTROL/*
└── tests/         # unit tests (xmltv, timezone, translation, sources,
                   # scheduler, channel mapper, beIN parser regression)
```

## Installation

**Option A - local installer (recommended for now):**

1. Copy the whole `EPGManager/` folder to your receiver (e.g. via `scp` or
   an image's file manager) to any temporary location, e.g. `/tmp/EPGManager`.
2. On the receiver:
   ```sh
   cd /tmp/EPGManager/installer
   sh install.sh
   ```
3. Restart Enigma2 (or reboot). The plugin appears under
   **Menu -> Extensions** (and also under the Plugins list).

**Option B - build a real `.ipk`:**

```sh
cd EPGManager/installer
sh build_ipk.sh
# produces enigma2-plugin-extensions-epgmanager_1.0.0_all.ipk
# copy it to the receiver, then:
opkg install enigma2-plugin-extensions-epgmanager_1.0.0_all.ipk
```

No package feed/repository URL is published yet - this only builds the
`.ipk` file locally, ready to be hosted on a feed later if you want one.

**If you're migrating from the old cron-based scripts:** remove their
crontab entries (the ones in the `root` file you were using before) so
updates don't run twice - `install.sh` does **not** touch your crontab.

## Supported Vu+ receivers

The plugin is architecture-generic (pure Python 3 + Enigma2 APIs, no native
extensions). It has no receiver-specific code paths, so it should run on
any Vu+ Enigma2 model capable of running Python 3, including: Zero, Zero
4K, Solo, Solo 2, Solo SE, Solo 4K, Uno, Uno 4K, Uno 4K SE, Duo, Duo 2, Duo
4K, Duo 4K SE, Ultimo, Ultimo 4K, and other Vu+ Enigma2 models. **Only the
Vu+ Zero 4K has been used as the reference development target** - the rest
are "should work" based on architecture-independence, not individually
verified.

## Supported Enigma2 images / compatibility matrix

| Image | Python | Architecture | Status | Tested | Known limitations |
|---|---|---|---|---|---|
| OpenATV | 3.x | any | Should work | **Untested** | Uses only `Components.config`, `Screens.Screen`, `enigma.eTimer` - all standard across images |
| OpenPLi | 3.x | any | Should work | **Untested** | Same as above |
| OpenViX | 3.x | any | Should work | **Untested** | Same as above |
| OpenBH | 3.x | any | Should work | **Untested** | Same as above |
| Egami | 3.x | any | Should work | **Untested** | Same as above |
| VTi | 3.x | any | Should work | **Untested** | Same as above |
| Non-Enigma2 (dev/CI) | 3.7+ | any | Supported | **Tested** | `core/config.py` and `core/scheduler.py` auto-detect the absence of Enigma2 and fall back to a JSON config file / `threading.Timer`, so the full test suite runs outside Enigma2 |

**Important honesty note:** none of the Enigma2-image rows above have been
run against a real receiver as part of this project - I do not have access
to physical Vu+ hardware or an Enigma2 emulator to verify GUI behavior.
The GUI code (`ui/*.py`) follows standard Enigma2 plugin conventions
(`Screen`, `ActionMap`, `ConfigList`, `eTimer`) that are consistent across
all listed images, but **please test on your actual receiver before relying
on it**, and report back anything that doesn't render correctly.

## Python compatibility

- Targets Python 3.7+ (widely available across current Enigma2 images).
- Avoids `match`/`case`, PEP 585 generic subscripting (`tuple[str, str]`,
  `list[str]`), and `ET.indent()` (3.9+) in favor of a hand-rolled
  indent function (see `core/utils.py:indent_xml`) - this was actually a
  bug in the original `1.MEDI1TV.py`, which used `ET.indent()` directly.
- `core/timezone_manager.py` prefers `pytz`, falls back to `zoneinfo`
  (3.9+), falls back to a fixed offset as an absolute last resort (with a
  loud warning, since that reintroduces the Ramadan-offset bug on purpose
  just to keep the plugin bootable).

## Dependencies

| Package | Required? | Fallback if missing |
|---|---|---|
| `requests` | Yes | None - install via `opkg install python3-requests` |
| `pytz` | Yes (recommended) | `zoneinfo` (Python 3.9+), then fixed UTC+1 offset (logged warning) |
| `bs4` (BeautifulSoup) | No | Regex/`xml.etree`-based mini-parser, reduced accuracy |
| `lxml` | No | `html.parser` (bs4 backend) / `xml.etree` |
| `cloudscraper` | No | Plain `requests` (may fail against Cloudflare-style JS challenges on some sources) |

`install.sh` runs `core/dependencies.py` and attempts to install missing
**required** dependencies via `opkg` only - it never calls `pip install`
and never compiles anything on the receiver.

## Configuration

Settings screen (spec section 34) or `/etc/enigma2/epgmanager.conf`:

- Schedule mode: "daily" (default), "weekly" (pick a day), "monthly" (pick a day 1-28), or "interval" (every N hours)
- Daily update time (native ConfigClock picker, LEFT/RIGHT to adjust; default 06:00 Casablanca time)
- Update interval in hours (used only when schedule mode is "interval"; default 6)
- EPG days to fetch (default 7, per-source defaults/caps vary - see table below)
- EPG export directory (default `/etc/epgimport/jedi_epg`; where the six generated XMLTV files are written)
- Retry count per request (default 3)
- Timeout in seconds (default 15)
- Parallel workers (default 4, capped at 8)
- Logging level / debug mode
- Per-source enable/disable

| Source | Output file | Default days | Notes |
|---|---|---|---|
| Medi1 TV | `medi1tv_ar.xml` | 7 | URL corrected to `/ar/grille/arabic/<date>` (see below) |
| 2M / Chada | `2M_Chada.xml` | 7 | 2M times use Europe/Paris localization - see risk note below; day-fetches now run in parallel |
| SNRT | `snrt.xml` | up to 7 requested | site doesn't support a date parameter; ingests whatever the live grid shows |
| beIN Sports | `bein.xml` | 3 (hard-capped, see bug fixes below) | channel list is dynamic, discovered per run |
| Almajd | `almajdtv.xml` | 2 (hard-capped at 3) | matches source site's real forward window |
| Arryadia | `arryadia_snrt.xml` | 3 | auto-fills gaps with a 3h generic slot when no schedule data is found |

## Automatic updates

No cron. `plugin.py` registers a `WHERE_SESSIONSTART` hook; on Enigma2
boot, `core/scheduler.py` checks whether an update is due and, if so,
starts a background update via a `ThreadPoolExecutor` (never on the GUI
thread). It then re-checks every 5 minutes via `eTimer` so setting changes
take effect without a reboot.

Two scheduling modes (Settings -> Schedule mode):
- **daily** (default): runs once a day at a fixed time (06:00 Casablanca
  time by default, configurable). If the box was off at 06:00 and boots
  later that day, it still catches that day's update rather than waiting
  until tomorrow.
- **interval**: runs every N hours since the last successful update (the
  original behavior).

## Manual updates

Extensions menu -> EPG Manager opens the dashboard. Use `OK` to check/
uncheck which sources to include, then **RED** to update just the checked
ones (or **GREEN** to select all/none first). Press `9` to update only the
currently highlighted source right away, without touching the checkbox
selection at all. Press `0` to open a separate screen for *permanently*
enabling/disabling a source (excludes it from every future auto-update
too, not just the current run). While a run is in progress, **RED**
becomes **Cancel Update** (best-effort - see "What changed since the
first release" above).

## Channel mapping (auto-assign to real services)

Press `3` on the dashboard, or Extensions menu -> EPG Manager -> Channel
Mapping. This reads the channels already present in your generated XMLTV
files, scans every bouquet on the receiver, and shows which real services
matched by name and on which satellite(s)/bouquet(s). Press **GREEN** to
write `/etc/epgimport/epgmanager.sources.xml` for everything matched, then
open EPG-Importer's own Settings once (button `1`) to select/enable that
source list - this plugin does not silently edit EPG-Importer's internal
configuration for you.

## EPG paths

All XMLTV output goes to `/etc/epgimport/jedi_epg/`, matching the
filenames Jedi EPG Importer already expects (unchanged from the original
scripts - see table above). A `.bak` copy of the previous good file is kept
next to each output file.

## Logs

Rotating log at the first writable location found in: `/var/log`,
`/media/hdd/epgmanager/logs`, `/tmp/epgmanager/logs`. Capped at 2 MB x 4
files. The plugin's **Logs / About** screen shows the last 80 lines in a
scrollable viewer (UP/DOWN to scroll a page at a time, `0`/`9` to jump to
the top/bottom).

## Debug mode

Enable "Debug mode" in Settings for verbose logging. For CLI-level
diagnostics outside the GUI:

```sh
python3 -c "from EPGManager.core import dependencies; import json; print(json.dumps(dependencies.scan(), indent=2, default=str))"
```

This is diagnostic-only - normal operation is always controlled by the
Enigma2 plugin lifecycle, never by manually running a source script.

## Uninstallation

```sh
cd /path/to/EPGManager/installer
sh uninstall.sh                 # removes plugin code only (default, safest)
sh uninstall.sh --remove-epg    # also deletes generated XML files
sh uninstall.sh --remove-config # also deletes epgmanager.conf
sh uninstall.sh --purge-all     # removes everything, including custom_dictionary.json
```

## What changed vs the original scripts (bug fixes)

1. **Arryadia's hardcoded `UTC+1` timezone** (`timezone(timedelta(hours=1))`)
   was wrong during Morocco's Ramadan DST pause. Now uses the shared
   `TimezoneManager` (Africa/Casablanca + Hijri cross-check, promoted from
   the original 2M/Chada script's best-in-class logic).
2. **Medi1TV's grid URL** was `https://www.medi1tv.com/ar/grille/<date>`;
   verified live against the site on 2026-08-09, the real URL is
   `https://www.medi1tv.com/ar/grille/arabic/<date>` (missing `/arabic/`
   segment). Fixed.
3. **No source ever kept a backup / refused to overwrite a good file with
   an empty one.** Every source now goes through
   `core/xmltv.py:XMLTVBuilder.save()`, which validates before writing,
   keeps a `.bak`, and refuses the write entirely if validation fails or
   the minimum program count isn't met.
4. **`tuple[str, str, bool]` return type hint** in Arryadia's
   `format_football_title()` used PEP 585 generic subscripting
   (Python 3.9+ only) - removed for broader Python compatibility.
5. **beIN Sports returned 0 events (found and fixed 2026-08-09).** Three
   compounding bugs, all introduced during the original port, not present
   in the working standalone script:
   - The parser's "primary/fallback" logic checked *"is bs4 installed"*
     instead of *"did the parser find anything"* - since bs4 is installed,
     it always used a new structural parser with its own bug (it searched
     for `data-img`/`live` as descendant attributes, but they're actually
     on the `<li>` tag itself), and never fell through to the original,
     proven-working regex parser. Fixed: regex now runs first,
     unconditionally; bs4 is only a fallback when regex finds nothing.
   - SSL verification had been turned back on as a general hardening pass,
     but the original script's `verify=False` (paired with
     `urllib3.disable_warnings`) was deliberate - beIN's cert chain
     appears to need it. Restored specifically for this source.
   - The global "EPG days" setting (default 7) silently overrode the
     original's deliberate 3-day cap (its own "Anti-Ban" comment), more
     than doubling request volume against a site already tuned to avoid
     rate-limiting. Re-capped at 3.
6. **2M/Chada took 300+ seconds per run (found and fixed 2026-08-09).**
   The original translator makes a single 5-second-timeout attempt with no
   retry and falls back to the original text on failure - fast by design,
   since Google's free translate endpoint is inherently flaky. The ported
   version accidentally routed it through the shared retrying downloader
   (3 attempts + exponential backoff), turning every failed translation
   into a ~7-10s stall instead of an instant fallback; with ~140
   translation calls per run this plausibly accounted for most of the
   slowdown. Fixed: the translator now always builds its own fast,
   single-attempt downloader. The 7-day fetch loop is also now
   parallelized (days are independent; only the 5 periods *within* a day
   must stay sequential for state tracking).
7. **SNRT's per-programme detail-page fetcher had the identical retry bug**
   as #6 above (many detail pages 404/timeout, each costing 3x as long as
   necessary) - fixed the same way.
8. **No unified retry/backoff** for the main grid-page fetches - Medi1TV
   and Almajd had zero retries; SNRT/Arryadia/beIN had partial,
   inconsistent retry logic. All sources now go through
   `core/downloader.py`, which retries transient errors (timeouts,
   connection errors, 429/5xx) with exponential backoff and fails fast on
   non-transient errors (403/404).

## Known limitations (not silently "fixed" - documented per your instructions)

- **SNRT** does not accept a date parameter on its grid pages; it can only
  ingest whatever window the live page currently shows, unlike the other
  sources' explicit day-by-day loop.
- **2M's schedule source** (`tv-programme.telecablesat.fr`) displays times
  that the original script treats as `Europe/Paris`. Paris observes DST
  (UTC+2 in summer) while Morocco holds a fixed UTC+1 outside Ramadan. If
  the displayed times are actually meant as Moroccan broadcast wall-clock
  rather than genuine Paris time, 2M's schedule could be off by one hour
  during the European summer. The original behavior is preserved as-is
  because confirming which is correct requires comparing against 2M's own
  real broadcast schedule, which could not be verified from these source
  files alone.
- **SNRT and Arryadia both scrape snrt.ma**, which returned a
  "JavaScript is required" interstitial to this project's own
  verification fetch on 2026-08-09. This may be specific to that
  fetch tool (no cookies/JS execution) rather than a real block against
  `requests` + a browser User-Agent - the original scripts were
  apparently working with plain `requests`. Both sources are configured
  with `use_cloudscraper = True` so they automatically try the
  `cloudscraper` fallback if installed; if snrt.ma has in fact added
  anti-bot protection, install `cloudscraper` via pip in a controlled
  environment, or watch the logs for repeated failures.
- **beIN's live-flag regex is order-sensitive** (a fragility in the
  *original* script, documented by `tests/test_bein_parser.py`): it only
  detects `live="1"` when that's the first attribute right after `<li`. If
  beIN ever reorders attributes, live events would stop being tagged
  "Live:" (though the events themselves would still appear - the bs4
  fallback parser doesn't have this problem, but only runs when the regex
  parser finds zero events, not when it finds events with wrong live-flags).
- **Channel mapping match quality depends entirely on your bouquet naming.**
  If a bouquet's channel name is significantly different from the EPG's
  display name (not just an HD/SD/case difference), it won't be found
  automatically - you'll see it listed with "no match" and can still map
  it by hand inside EPG-Importer directly.
- **The EPG-Importer/JediEPGXtream quick-launch buttons** find and open
  whichever matching plugin is installed via Enigma2's own plugin
  registry, and try to avoid descriptors that look like they trigger an
  immediate action - but this plugin has no control over what happens
  inside another plugin once it's launched.
- **GUI screens are untested on real Enigma2 hardware** beyond what you've
  already reported back (see compatibility matrix above).

## Running the tests

From the directory that **contains** the `EPGManager/` folder:

```sh
python3 -m unittest discover -s . -p "test_*.py" -t .
```

Or run individual modules, e.g.:

```sh
python3 -m unittest EPGManager.tests.test_xmltv EPGManager.tests.test_timezone \
                     EPGManager.tests.test_translation EPGManager.tests.test_sources \
                     EPGManager.tests.test_scheduler EPGManager.tests.test_channel_mapper \
                     EPGManager.tests.test_epgimport_export EPGManager.tests.test_bein_parser -v
```

(`ui/*.py` and `plugin.py` import Enigma2-only modules like `enigma` and
`Screens.Screen` and can only be exercised on an actual receiver or against
an Enigma2 stub environment - they are not part of the offline test suite.)

## v2.3.0 UI/UX refresh
- Full-screen veil removed so live TV keeps its native colours.
- Matrix/OpenATV glass panels remain for readability and visual consistency.
- Source rows are now continuous bands instead of disconnected grid cells.
- Selection marker changed to a compact cyan tile; navigation highlight stays independent.
- Source details panel now includes EPG date range and concise error information.
- Safety: a one-source update cannot start while another update job is already active.


## v4.0 Standalone EPG Engine

EPG Manager 4.0 can now operate without EPG-Importer or JediEPGXtream for its core EPG workflow.

- **1 Native Import** builds a mapping plan from the generated XMLTV files and injects mapped events directly into Enigma2's native EPG cache.
- **2 Smart Mapping** scans all `userbouquet.*.tv` files, scores channel-name candidates, automatically accepts high-confidence matches and lets the user save a manual service-reference override with OK.
- Manual mapping overrides persist in `/etc/enigma2/epgmanager_mappings.json`.
- The existing `epgmanager.sources.xml` export remains available only as a compatibility bridge; it is no longer required by EPG Manager itself.
- IPTV service references are kept exactly as they appear in the receiver bouquet, so 4097/5001/5002-style services can be mapped without rewriting the bouquet.

The native importer deliberately checks for `eEPGCache.importEvents` at runtime. If an unusual Enigma2 image does not expose that API, the plugin reports the incompatibility instead of crashing the GUI.


## v5.0 Performance & Automation
- Persistent bouquet cache for large 10k+ service receivers
- SAT/IPTV/DVB service classification and DVB IDs
- Safe Auto Map All (default 95% confidence)
- Mapping backup/history/undo support
- Repair mode and mapping coverage
- Optional native auto-import after update setting

## Online Update (v6.0+)
Press **8** on the main screen to open Online Update. Configure an HTTPS `update.json`
manifest once with the YELLOW key. EPG Manager can then check, download, SHA-256 verify,
install the IPK with `opkg`, and offer to restart Enigma2 without copying an IPK manually.
See `online_update/README_ONLINE_UPDATE.txt` in the project archive.
