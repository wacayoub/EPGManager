EPG Manager - Online Update server
==================================

1. Upload update.json and the new .ipk to any public HTTPS folder, GitHub raw/static hosting,
   or your own web server.
2. On the Vu+: EPG Manager -> press 8 Online Update -> YELLOW Update Server.
3. Enter the public URL to update.json once.
4. Future updates: press 8 -> GREEN Check Update -> BLUE Install Update.

Recommended update.json format:
{
  "version": "6.0.1",
  "url": "enigma2-plugin-extensions-epgmanager_6.0.1_all.ipk",
  "sha256": "...64 hex chars...",
  "size": 123456,
  "notes": "Release notes"
}

The IPK URL can be relative to the update.json URL. SHA-256 is strongly recommended.
