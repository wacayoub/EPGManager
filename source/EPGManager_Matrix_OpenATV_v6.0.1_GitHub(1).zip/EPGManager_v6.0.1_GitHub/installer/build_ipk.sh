#!/bin/sh
# ==========================================================================
# build_ipk.sh - assembles enigma2-plugin-extensions-epgmanager_1.0.0_all.ipk
#
# Run this on a Linux machine with `tar`, `ar` (or `opkg-build` if
# available) installed - it does NOT need to run on the receiver itself.
# The resulting .ipk can then be copied to the receiver and installed with:
#     opkg install enigma2-plugin-extensions-epgmanager_1.0.0_all.ipk
#
# This is provided as spec section 41 requests ("explain how it can later
# be packaged into an .ipk") - no package feed/repository URL is invented;
# this only builds the local file.
# ==========================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILD_DIR="$(mktemp -d)"
PKG_NAME="enigma2-plugin-extensions-epgmanager"
PKG_VERSION="6.0.1"
OUT_FILE="$PROJECT_ROOT/${PKG_NAME}_${PKG_VERSION}_all.ipk"

echo "[*] Building $OUT_FILE"

if command -v opkg-build >/dev/null 2>&1; then
    # Preferred path: use the real opkg-build tool if present.
    STAGE="$BUILD_DIR/stage"
    DATA_ROOT="$STAGE/usr/lib/enigma2/python/Plugins/Extensions/EPGManager"
    mkdir -p "$DATA_ROOT" "$STAGE/CONTROL"
    for item in __init__.py plugin.py plugin.png version.py core sources translators ui config data icons; do
        cp -r "$PROJECT_ROOT/$item" "$DATA_ROOT/"
    done
    cp "$SCRIPT_DIR/ipk/CONTROL/control" "$STAGE/CONTROL/control"
    cp "$SCRIPT_DIR/ipk/CONTROL/postinst" "$STAGE/CONTROL/postinst"
    cp "$SCRIPT_DIR/ipk/CONTROL/prerm" "$STAGE/CONTROL/prerm"
    chmod 755 "$STAGE/CONTROL/postinst" "$STAGE/CONTROL/prerm"
    opkg-build "$STAGE" "$PROJECT_ROOT"
else
    # Fallback: build the ipar (ar archive of tarballs) format by hand.
    echo "[!] opkg-build not found - building the .ipk manually via ar/tar."
    DATA_STAGE="$BUILD_DIR/data_stage"
    DATA_ROOT="$DATA_STAGE/usr/lib/enigma2/python/Plugins/Extensions/EPGManager"
    mkdir -p "$DATA_ROOT"
    for item in __init__.py plugin.py plugin.png version.py core sources translators ui config data icons; do
        cp -r "$PROJECT_ROOT/$item" "$DATA_ROOT/"
    done
    mkdir -p "$DATA_STAGE/etc/epgimport/jedi_epg"

    ( cd "$DATA_STAGE" && tar -czf "$BUILD_DIR/data.tar.gz" . )

    CONTROL_STAGE="$BUILD_DIR/control_stage"
    mkdir -p "$CONTROL_STAGE"
    cp "$SCRIPT_DIR/ipk/CONTROL/control" "$CONTROL_STAGE/control"
    cp "$SCRIPT_DIR/ipk/CONTROL/postinst" "$CONTROL_STAGE/postinst"
    cp "$SCRIPT_DIR/ipk/CONTROL/prerm" "$CONTROL_STAGE/prerm"
    chmod 755 "$CONTROL_STAGE/postinst" "$CONTROL_STAGE/prerm"
    ( cd "$CONTROL_STAGE" && tar -czf "$BUILD_DIR/control.tar.gz" ./control ./postinst ./prerm )

    echo "2.0" > "$BUILD_DIR/debian-binary"

    ( cd "$BUILD_DIR" && ar rc "$OUT_FILE" debian-binary control.tar.gz data.tar.gz )
fi

echo "[*] Done: $OUT_FILE"
rm -rf "$BUILD_DIR"
