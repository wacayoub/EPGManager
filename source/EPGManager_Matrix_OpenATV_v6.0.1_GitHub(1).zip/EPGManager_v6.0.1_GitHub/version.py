# -*- coding: utf-8 -*-
"""EPG Manager - version information."""

__version__ = "6.0.1"
__build__ = "2026.08.09"
__author__ = "EPG Manager Project"
CONFIG_SCHEMA_VERSION = 4
VERSION = __version__
