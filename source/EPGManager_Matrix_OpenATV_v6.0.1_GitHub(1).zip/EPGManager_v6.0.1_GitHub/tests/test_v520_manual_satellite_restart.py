# -*- coding: utf-8 -*-
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_version_520():
    text = (ROOT / 'version.py').read_text()
    assert '__version__ = "6.0.0"' in text


def test_satellite_virtual_bouquet_and_mapping_details_present():
    text = (ROOT / 'ui' / 'channel_mapping.py').read_text()
    assert '"virtual": "satellite"' in text
    assert 'SATELLITE CHANNELS' in text
    assert 'mapped.png' in text
    assert 'def _mapping_suffix' in text
    assert '=>  ' in text


def test_mapping_save_uses_compact_json_for_speed():
    text = (ROOT / 'core' / 'mapping_store.py').read_text()
    assert 'separators=(",", ":")' in text
    assert 'indent=2, sort_keys=True' not in text


def test_restart_confirmation_after_manual_scripts():
    main = (ROOT / 'ui' / 'main.py').read_text()
    mapping = (ROOT / 'ui' / 'channel_mapping.py').read_text()
    assert 'Restart Enigma2 now?' in main
    assert 'Restart Enigma2 now?' in mapping
    assert 'TryQuitMainloop' in main
    assert 'TryQuitMainloop' in mapping
